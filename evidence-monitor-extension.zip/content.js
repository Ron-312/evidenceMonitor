"use strict";
(() => {
  // src/scripts/content.ts
  var HUD = class {
    // 3 seconds timeout
    constructor() {
      this.state = {
        recording: false,
        eventCount: 0,
        atCap: false,
        recordingMode: "console",
        filters: {
          elementSelector: "",
          attributeFilters: "",
          stackKeywordFilter: ""
        },
        trackEvents: {
          inputValueAccess: true,
          inputEvents: true,
          formSubmit: true,
          formDataCreation: true
        },
        theme: "dark",
        minimized: true
        // Default to minimized to prevent flickering
      };
      this.exportPreviewShown = false;
      this.messageHideTimeout = null;
      // UI update throttling properties
      this.updateThrottle = /* @__PURE__ */ new Map();
      this.updateInterval = 200;
      // 200ms throttle for UI updates
      this.pendingUpdate = false;
      // Loading state management
      this.isLoading = true;
      this.loadingTimeout = null;
      this.loadingTimeoutDuration = 3e3;
      console.debug("[HUD] \u{1F3AF} HUD constructor called");
      const existingHUD = document.getElementById("evidence-hud-overlay");
      if (existingHUD) {
        console.warn("[HUD] \u26A0\uFE0F HUD element already exists during constructor! This might cause issues.");
      }
      try {
        const savedTheme = localStorage.getItem("hud-theme");
        if (savedTheme === "light" || savedTheme === "dark") {
          this.state.theme = savedTheme;
        }
        const savedMinimized = localStorage.getItem("hud-minimized");
        if (savedMinimized === "true" || savedMinimized === "false") {
          this.state.minimized = savedMinimized === "true";
        }
      } catch (error) {
        console.warn("[HUD] Failed to load preferences:", error);
      }
      this.hudElement = this.createHUD();
      this.attachHUD();
      this.hideHUDDuringLoading();
      this.setupMessageListener();
      this.startLoadingTimeout();
      this.requestStatus();
      console.debug("[HUD] \u2705 HUD constructor complete, element attached to DOM (hidden during loading)");
    }
    createHUD() {
      const hud = document.createElement("div");
      hud.id = "evidence-hud-overlay";
      hud.innerHTML = `
      <div class="hud-header">
        <h3>Input Monitoring</h3>
        <div class="hud-header-controls">
          <button class="user-guide-toggle" title="Open User Guide">?</button>
          <button class="minimize-toggle" title="Minimize HUD">\u2212</button>
          <button class="theme-toggle" title="Toggle light/dark theme">
            <svg viewBox="0 0 20 20" class="theme-icon">
              <!-- Moon icon (dark theme) -->
              <path class="moon-icon" d="M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z"/>
              <!-- Sun icon (light theme) -->
              <g class="sun-icon" style="display: none;">
                <circle cx="10" cy="10" r="4"/>
                <path d="M10 1v2M10 17v2M4.22 4.22l1.42 1.42M14.36 14.36l1.42 1.42M1 10h2M17 10h2M4.22 15.78l1.42-1.42M14.36 5.64l1.42-1.42"/>
              </g>
            </svg>
          </button>
        </div>
      </div>
      <div class="hud-content">
        
        <!-- Status Display -->
        <div class="status-section">
          <div class="recording-status">Not Recording</div>
          <div class="window-context">Window recording session</div>
          <div class="event-count">Events captured: 0</div>
        </div>
        
        <!-- Basic Controls -->
        <div class="controls-section">
          <button class="start-recording">Start Recording</button>
          <button class="stop-recording" disabled>Stop Recording</button>
          <button class="export-data" disabled>Export Data</button>
          <button class="clear-data" disabled>Clear Data</button>
        </div>

        <!-- Message Display -->
        <div class="message-display" style="display: none;"></div>
        
        <!-- Recording Mode Options -->
        <div class="recording-mode-section">
          <h4 class="recording-mode-header">
            <span>Recording Mode</span>
            <button class="recording-mode-toggle" type="button">\u25BC</button>
          </h4>
          <div class="recording-mode-content" style="display: none;">
            <div class="toggle-switch-container">
              <span class="toggle-label left">Console</span>
              <div class="toggle-switch" data-mode="console">
                <div class="toggle-slider"></div>
              </div>
              <span class="toggle-label right">Breakpoint</span>
            </div>
          </div>
        </div>
        
        <!-- Filter Options Section -->
        <div class="filter-section">
          <h4 class="filter-header">
            <span>Filter Options</span>
            <button class="filter-toggle" type="button">\u25BC</button>
          </h4>
          <div class="filter-content" style="display: none;">
            <div class="filter-option">
              <label for="elementSelector">Element Selector (CSS):</label>
              <input type="text" id="elementSelector" class="element-selector" 
                     placeholder="e.g., #myInput, .password, input[name='secret']">
            </div>
            <div class="filter-option">
              <label for="attributeFilters">Attribute Filters:</label>
              <input type="text" id="attributeFilters" class="attribute-filters" 
                     placeholder="e.g., name=password, type=email">
            </div>
            <div class="filter-option">
              <label for="stackKeywordFilter">Stack Keyword Filter:</label>
              <input type="text" id="stackKeywordFilter" class="stack-keyword-filter" 
                     placeholder="e.g., analytics, tracking">
            </div>
          </div>
        </div>

        <!-- Track Events Section -->
        <div class="track-events-section">
          <h4 class="track-events-header">
            <span>Track Events</span>
            <button class="track-events-toggle" type="button">\u25BC</button>
          </h4>
          <div class="track-events-content" style="display: none;">
            <div class="track-events-option">
              <label>
                <input type="checkbox" class="input-value-access" checked>
                <span>Input Value Access</span>
              </label>
              <div class="track-events-description">Monitor property getters (value, nodeValue)</div>
            </div>
            <div class="track-events-option">
              <label>
                <input type="checkbox" class="input-events" checked>
                <span>Input Events</span>
              </label>
              <div class="track-events-description">Monitor addEventListener calls (keydown, input, change)</div>
            </div>
            <div class="track-events-option">
              <label>
                <input type="checkbox" class="form-submit" checked>
                <span>Form Submit</span>
              </label>
              <div class="track-events-description">Monitor form submission events and handlers</div>
            </div>
            <div class="track-events-option">
              <label>
                <input type="checkbox" class="form-data-creation" checked>
                <span>FormData Creation</span>
              </label>
              <div class="track-events-description">Monitor new FormData() constructor calls</div>
            </div>
          </div>
        </div>
             
        <!-- TODO: Advanced Features
             - Real-time event feed/log display
             - Event filtering by domain/source
             - Stack trace highlighting
             - Export format options (JSON, CSV)
             - Session management (save/load configurations) -->
      </div>

      <!-- Minimized Circle -->
      <div class="hud-minimized" style="display: none;">
        <div class="hud-minimized-circle">
          <div class="hud-minimized-inner">
            <svg viewBox="0 0 20 20">
              <circle cx="8" cy="8" r="6"/>
              <path d="m14 14 4 4"/>
            </svg>
          </div>
        </div>
      </div>

      <!-- User Guide Popup -->
      <div class="user-guide-popup" style="display: none;">
        <div class="user-guide-content">
          <div class="user-guide-header">
            <h3>Evidence Monitor User Guide</h3>
            <button class="user-guide-close" title="Close Guide">\xD7</button>
          </div>
          <div class="user-guide-body">
            <h4>\u{1F3AF} Getting Started</h4>
            <p>1. Click <strong>Start Recording</strong> to begin monitoring input surveillance</p>
            <p>2. Interact with elements on the page to capture evidence</p>
            <p>3. Use filters to focus on specific elements or scripts</p>

            <h4>\u{1F50D} Filter Options</h4>
            <div class="guide-section">
              <p><strong>Element Selector:</strong> CSS selector to target specific elements</p>
              <code>Example: input[name="password"], .secret-field</code>

              <p><strong>Attribute Filters:</strong> Key-value pairs for element attributes</p>
              <code>Example: name=username, type=password</code>

              <p><strong>Stack Keyword Filter:</strong> Scripts to monitor in call stack</p>
              <code>Example: analytics, fbevents, tracking</code>
            </div>

            <h4>\u{1F527} Filter Behavior</h4>
            <div class="guide-section">
              <p><strong>Single Filter:</strong> Only that filter type must match</p>
              <p><strong>Multiple Filters:</strong> ALL filter types must match (AND logic)</p>
              <p><strong>No Filters:</strong> Monitor everything</p>
            </div>

            <h4>\u{1F4CA} Track Events</h4>
            <div class="guide-section">
              <p><strong>Input Value Access:</strong> Detects when scripts read input values</p>
              <p><strong>Input Events:</strong> Monitors event listeners on form elements</p>
              <p><strong>Form Submit:</strong> Tracks form submission attempts</p>
              <p><strong>FormData Creation:</strong> Catches new FormData() calls</p>
            </div>

            <h4>\u{1F4DD} Recording Modes</h4>
            <div class="guide-section">
              <p><strong>Console:</strong> Log events to browser developer console</p>
              <p><strong>Breakpoint:</strong> Pause JavaScript execution when surveillance detected</p>
            </div>

            <h4>\u{1F4BE} Export & Clear</h4>
            <div class="guide-section">
              <p><strong>Export Data:</strong> Download captured evidence as JSON</p>
              <p><strong>Clear Data:</strong> Remove all recorded evidence</p>
            </div>
          </div>
        </div>
      </div>
    `;
      return hud;
    }
    attachHUD() {
      document.body.appendChild(this.hudElement);
      this.setupEventHandlers();
      this.makeDraggable();
    }
    hideHUDDuringLoading() {
      this.hudElement.style.display = "none";
      console.debug("[HUD] Hidden during loading state");
    }
    showHUDAfterLoading() {
      if (this.isLoading) {
        this.isLoading = false;
        this.hudElement.style.display = "block";
        this.updateUI();
        console.debug("[HUD] Shown after loading state resolved");
      }
    }
    startLoadingTimeout() {
      this.loadingTimeout = window.setTimeout(() => {
        if (this.isLoading) {
          console.warn("[HUD] Loading timeout reached, showing HUD with current state");
          this.showHUDAfterLoading();
        }
      }, this.loadingTimeoutDuration);
    }
    setupEventHandlers() {
      const startBtn = this.hudElement.querySelector(".start-recording");
      const stopBtn = this.hudElement.querySelector(".stop-recording");
      const exportBtn = this.hudElement.querySelector(".export-data");
      const clearBtn = this.hudElement.querySelector(".clear-data");
      const themeToggle = this.hudElement.querySelector(".theme-toggle");
      const minimizeToggle = this.hudElement.querySelector(".minimize-toggle");
      const userGuideToggle = this.hudElement.querySelector(".user-guide-toggle");
      const userGuideClose = this.hudElement.querySelector(".user-guide-close");
      const toggleSwitch = this.hudElement.querySelector(".toggle-switch");
      startBtn?.addEventListener("click", () => this.toggleRecording());
      stopBtn?.addEventListener("click", () => this.toggleRecording());
      exportBtn?.addEventListener("click", () => this.exportData());
      clearBtn?.addEventListener("click", () => this.clearData());
      toggleSwitch?.addEventListener("click", () => this.onRecordingModeToggle());
      themeToggle?.addEventListener("click", () => this.onThemeToggle());
      minimizeToggle?.addEventListener("click", () => this.onMinimizeToggle());
      userGuideToggle?.addEventListener("click", () => this.onUserGuideToggle());
      userGuideClose?.addEventListener("click", (event) => {
        event.stopPropagation();
        event.preventDefault();
        this.onUserGuideClose();
      });
      this.setupRecordingModeHandlers();
      this.setupFilterHandlers();
      this.setupTrackEventsHandlers();
      this.setupMinimizedHandlers();
    }
    setupFilterHandlers() {
      const filterHeader = this.hudElement.querySelector(".filter-header");
      const filterToggle = this.hudElement.querySelector(".filter-toggle");
      const filterContent = this.hudElement.querySelector(".filter-content");
      const elementSelectorInput = this.hudElement.querySelector(".element-selector");
      const attributeFiltersInput = this.hudElement.querySelector(".attribute-filters");
      const stackKeywordFilterInput = this.hudElement.querySelector(".stack-keyword-filter");
      const toggleFilter = () => {
        const isVisible = filterContent.style.display !== "none";
        filterContent.style.display = isVisible ? "none" : "block";
        filterToggle.textContent = isVisible ? "\u25BC" : "\u25B2";
      };
      filterHeader?.addEventListener("click", toggleFilter);
      elementSelectorInput?.addEventListener("input", () => this.onFilterChange());
      attributeFiltersInput?.addEventListener("input", () => this.onFilterChange());
      stackKeywordFilterInput?.addEventListener("input", () => this.onFilterChange());
    }
    setupTrackEventsHandlers() {
      const trackEventsHeader = this.hudElement.querySelector(".track-events-header");
      const trackEventsToggle = this.hudElement.querySelector(".track-events-toggle");
      const trackEventsContent = this.hudElement.querySelector(".track-events-content");
      const inputValueAccessCheckbox = this.hudElement.querySelector(".input-value-access");
      const inputEventsCheckbox = this.hudElement.querySelector(".input-events");
      const formSubmitCheckbox = this.hudElement.querySelector(".form-submit");
      const formDataCreationCheckbox = this.hudElement.querySelector(".form-data-creation");
      const toggleTrackEvents = () => {
        const isVisible = trackEventsContent.style.display !== "none";
        trackEventsContent.style.display = isVisible ? "none" : "block";
        trackEventsToggle.textContent = isVisible ? "\u25BC" : "\u25B2";
      };
      trackEventsHeader?.addEventListener("click", toggleTrackEvents);
      inputValueAccessCheckbox?.addEventListener("change", () => this.onTrackEventsChange());
      inputEventsCheckbox?.addEventListener("change", () => this.onTrackEventsChange());
      formSubmitCheckbox?.addEventListener("change", () => this.onTrackEventsChange());
      formDataCreationCheckbox?.addEventListener("change", () => this.onTrackEventsChange());
    }
    setupMinimizedHandlers() {
      const minimizedCircle = this.hudElement.querySelector(".hud-minimized-circle");
      if (!minimizedCircle) return;
      let isDragging = false;
      let hasMoved = false;
      let startX = 0;
      let startY = 0;
      let startLeft = 0;
      let startTop = 0;
      const DRAG_THRESHOLD = 5;
      minimizedCircle.addEventListener("mousedown", (e) => {
        isDragging = true;
        hasMoved = false;
        startX = e.clientX;
        startY = e.clientY;
        const hudRect = this.hudElement.getBoundingClientRect();
        startLeft = hudRect.left;
        startTop = hudRect.top;
        e.preventDefault();
        e.stopPropagation();
      });
      document.addEventListener("mousemove", (e) => {
        if (!isDragging) return;
        const deltaX = e.clientX - startX;
        const deltaY = e.clientY - startY;
        if (!hasMoved && (Math.abs(deltaX) > DRAG_THRESHOLD || Math.abs(deltaY) > DRAG_THRESHOLD)) {
          hasMoved = true;
        }
        if (hasMoved) {
          let newLeft = startLeft + deltaX;
          let newTop = startTop + deltaY;
          const circleSize = 50;
          const maxLeft = window.innerWidth - circleSize;
          const maxTop = window.innerHeight - circleSize;
          newLeft = Math.max(0, Math.min(newLeft, maxLeft));
          newTop = Math.max(0, Math.min(newTop, maxTop));
          this.hudElement.style.left = newLeft + "px";
          this.hudElement.style.top = newTop + "px";
          this.hudElement.style.right = "auto";
        }
      });
      document.addEventListener("mouseup", (e) => {
        if (isDragging) {
          isDragging = false;
          if (!hasMoved) {
            this.onMinimizeToggle();
          }
          hasMoved = false;
        }
      });
    }
    setupRecordingModeHandlers() {
      const recordingModeHeader = this.hudElement.querySelector(".recording-mode-header");
      const recordingModeToggle = this.hudElement.querySelector(".recording-mode-toggle");
      const recordingModeContent = this.hudElement.querySelector(".recording-mode-content");
      const toggleRecordingMode = () => {
        const isVisible = recordingModeContent.style.display !== "none";
        recordingModeContent.style.display = isVisible ? "none" : "block";
        recordingModeToggle.textContent = isVisible ? "\u25BC" : "\u25B2";
      };
      recordingModeHeader?.addEventListener("click", toggleRecordingMode);
    }
    setupMessageListener() {
      chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        switch (message.type) {
          case "HUD_UPDATE":
            this.updateState({
              recording: message.recording ?? this.state.recording,
              eventCount: message.eventCount ?? this.state.eventCount,
              atCap: message.atCap ?? this.state.atCap
            });
            break;
          case "HUD_MESSAGE":
            if (!this.exportPreviewShown) {
              this.showMessage(message.message, message.level || "info");
            }
            break;
        }
      });
    }
    requestStatus() {
      console.debug("[HUD] Requesting status from background...");
      chrome.runtime.sendMessage({ type: "GET_STATUS" }, (response) => {
        console.debug("[HUD] Received status response from background:", response);
        if (response) {
          let recordingMode = response.recordingMode;
          if (!recordingMode) {
            console.error("[HUD] \u274C CRITICAL: Background returned no recordingMode!", {
              fullResponse: response,
              resettingToConsole: true
            });
            recordingMode = "console";
          }
          const stateUpdate = {
            recording: response.recording,
            eventCount: response.eventCount,
            atCap: response.atCap,
            recordingMode,
            filters: response.filters || {
              elementSelector: "",
              attributeFilters: "",
              stackKeywordFilter: ""
            },
            trackEvents: response.trackEvents || {
              inputValueAccess: true,
              inputEvents: true,
              formSubmit: true,
              formDataCreation: true
            }
          };
          console.debug("[HUD] About to update state:", {
            originalRecordingMode: response.recordingMode,
            finalRecordingMode: stateUpdate.recordingMode,
            hadToReset: !response.recordingMode
          });
          this.updateState(stateUpdate);
          if (this.loadingTimeout) {
            clearTimeout(this.loadingTimeout);
            this.loadingTimeout = null;
          }
          this.showHUDAfterLoading();
        } else {
          console.warn("[HUD] No response received from background script");
          if (this.loadingTimeout) {
            clearTimeout(this.loadingTimeout);
            this.loadingTimeout = null;
          }
          this.showHUDAfterLoading();
        }
      });
    }
    toggleRecording() {
      chrome.runtime.sendMessage({ type: "TOGGLE_RECORDING" }, (response) => {
        if (response) {
          this.updateState({
            ...this.state,
            recording: response.recording
          });
          if (response.recording) {
            this.resetExportPreviewState();
          }
        }
      });
    }
    exportData() {
      if (!this.exportPreviewShown) {
        this.showExportPreview();
      } else {
        this.proceedWithExport();
      }
    }
    // Cancel export preview when other actions are taken
    cancelExportPreview() {
      if (this.exportPreviewShown) {
        this.resetExportPreviewState();
      }
    }
    showExportPreview() {
      chrome.runtime.sendMessage({ type: "GET_EXPORT_PREVIEW" }, (response) => {
        if (response && response.preview) {
          this.displayExportPreviewMessage(response.preview);
        } else {
          this.proceedWithExport();
        }
      });
    }
    displayExportPreviewMessage(preview) {
      const urls = Object.keys(preview);
      const totalEvents = Object.values(preview).reduce((sum, file) => sum + file.eventCount, 0);
      if (urls.length === 0) {
        this.showMessage("No events to export", "warning");
        return;
      }
      const truncateUrl = (url, maxLength = 50) => {
        if (url.length <= maxLength) return url;
        return url.substring(0, maxLength - 3) + "...";
      };
      const now = /* @__PURE__ */ new Date();
      const dateStr = now.toISOString().split("T")[0];
      const timeStr = now.toTimeString().split(" ")[0].replace(/:/g, "-");
      const sessionFolder = `evidence_session_${dateStr}_${timeStr}`;
      let message = `Ready to export ${totalEvents} events from ${urls.length} URL${urls.length !== 1 ? "s" : ""} into folder "${sessionFolder}"`;
      if (urls.length > 1) {
        const truncatedUrls = urls.map((url) => truncateUrl(url, 25));
        message += `. Files: ${truncatedUrls.join(", ")}`;
      } else {
        const url = urls[0];
        const eventCount = preview[url].eventCount;
        const displayUrl = truncateUrl(url, 50);
        message += `: ${displayUrl} (${eventCount} events)`;
      }
      message += `. You'll choose the location for the entire session folder.`;
      this.showPersistentMessage(message, "info");
      this.updateExportButtonForConfirmation();
      this.exportPreviewShown = true;
    }
    showPersistentMessage(message, level = "info") {
      if (this.messageHideTimeout !== null) {
        clearTimeout(this.messageHideTimeout);
        this.messageHideTimeout = null;
      }
      const messageDiv = this.hudElement.querySelector(".message-display");
      messageDiv.textContent = message;
      messageDiv.style.display = "block";
      messageDiv.className = `message-display message-${level}`;
      messageDiv.style.whiteSpace = "normal";
      messageDiv.style.wordWrap = "break-word";
      messageDiv.style.overflowWrap = "break-word";
      messageDiv.style.maxHeight = "80px";
      messageDiv.style.overflow = "auto";
      messageDiv.style.direction = "auto";
      messageDiv.style.textAlign = "start";
      messageDiv.style.unicodeBidi = "plaintext";
    }
    hidePersistentMessage() {
      const messageDiv = this.hudElement.querySelector(".message-display");
      messageDiv.style.display = "none";
    }
    updateExportButtonForConfirmation() {
      const exportBtn = this.hudElement.querySelector(".export-data");
      if (exportBtn) {
        exportBtn.textContent = "Confirm Export";
        exportBtn.style.backgroundColor = "#4CAF50";
      }
    }
    resetExportButton() {
      const exportBtn = this.hudElement.querySelector(".export-data");
      if (exportBtn) {
        exportBtn.textContent = "Export Data";
        exportBtn.style.backgroundColor = "";
      }
    }
    proceedWithExport() {
      chrome.runtime.sendMessage({ type: "EXPORT_EVENTS" });
      this.resetExportPreviewState();
    }
    clearData() {
      chrome.runtime.sendMessage({ type: "CLEAR_EVENTS" });
      this.resetExportPreviewState();
    }
    resetExportPreviewState() {
      this.exportPreviewShown = false;
      this.resetExportButton();
      this.hidePersistentMessage();
    }
    onThemeToggle() {
      const newTheme = this.state.theme === "dark" ? "light" : "dark";
      this.updateState({ theme: newTheme });
      try {
        localStorage.setItem("hud-theme", newTheme);
      } catch (error) {
        console.warn("[HUD] Failed to save theme preference:", error);
      }
    }
    onMinimizeToggle() {
      const newMinimized = !this.state.minimized;
      if (this.state.minimized && !newMinimized) {
        this.positionHUDFromMinimized();
      }
      this.updateState({ minimized: newMinimized });
      try {
        localStorage.setItem("hud-minimized", newMinimized.toString());
      } catch (error) {
        console.warn("[HUD] Failed to save minimize preference:", error);
      }
    }
    onUserGuideToggle() {
      const userGuidePopup = this.hudElement.querySelector(".user-guide-popup");
      if (userGuidePopup) {
        userGuidePopup.style.display = "block";
        console.debug("[HUD] User guide opened");
        const handleClickOutside = (event) => {
          const target = event.target;
          const userGuideContent = this.hudElement.querySelector(".user-guide-content");
          const closeButton = this.hudElement.querySelector(".user-guide-close");
          if (closeButton && closeButton.contains(target)) {
            return;
          }
          if (!userGuideContent.contains(target)) {
            this.onUserGuideClose();
            userGuidePopup.removeEventListener("click", handleClickOutside);
          }
        };
        userGuidePopup.addEventListener("click", handleClickOutside);
      }
    }
    onUserGuideClose() {
      const userGuidePopup = this.hudElement.querySelector(".user-guide-popup");
      if (userGuidePopup) {
        userGuidePopup.style.display = "none";
        console.debug("[HUD] User guide closed");
      }
    }
    positionAtBottomRight() {
      const rightMargin = 40;
      const bottomMargin = 20;
      const circleSize = 50;
      const rightPos = window.innerWidth - circleSize - rightMargin;
      const bottomPos = window.innerHeight - circleSize - bottomMargin;
      this.hudElement.style.left = rightPos + "px";
      this.hudElement.style.top = bottomPos + "px";
      this.hudElement.style.right = "auto";
      this.hudElement.style.bottom = "auto";
    }
    positionHUDFromMinimized() {
      const hudWidth = 350;
      const topMargin = 20;
      const rightMargin = 20;
      const rightPos = window.innerWidth - hudWidth - rightMargin;
      const topPos = topMargin;
      const safeX = Math.max(0, Math.min(rightPos, window.innerWidth - hudWidth));
      const safeY = Math.max(0, topPos);
      this.hudElement.style.left = safeX + "px";
      this.hudElement.style.top = safeY + "px";
      this.hudElement.style.right = "auto";
      this.hudElement.style.bottom = "auto";
    }
    onRecordingModeToggle() {
      console.debug("[HUD] Recording mode toggle clicked");
      const toggleSwitch = this.hudElement.querySelector(".toggle-switch");
      const currentMode = toggleSwitch.getAttribute("data-mode") || "console";
      const newMode = currentMode === "console" ? "breakpoint" : "console";
      console.debug(`[HUD] Toggling from ${currentMode} to ${newMode}`);
      this.updateState({ recordingMode: newMode });
      console.debug("[HUD] Sending SET_RECORDING_MODE message to background");
      chrome.runtime.sendMessage({
        type: "SET_RECORDING_MODE",
        recordingMode: newMode
      });
    }
    onFilterChange() {
      const elementSelectorInput = this.hudElement.querySelector(".element-selector");
      const attributeFiltersInput = this.hudElement.querySelector(".attribute-filters");
      const stackKeywordFilterInput = this.hudElement.querySelector(".stack-keyword-filter");
      const filters = {
        elementSelector: elementSelectorInput?.value || "",
        attributeFilters: attributeFiltersInput?.value || "",
        stackKeywordFilter: stackKeywordFilterInput?.value || ""
      };
      this.updateState({ filters });
      chrome.runtime.sendMessage({
        type: "SET_FILTERS",
        filters
      });
    }
    onTrackEventsChange() {
      const inputValueAccessCheckbox = this.hudElement.querySelector(".input-value-access");
      const inputEventsCheckbox = this.hudElement.querySelector(".input-events");
      const formSubmitCheckbox = this.hudElement.querySelector(".form-submit");
      const formDataCreationCheckbox = this.hudElement.querySelector(".form-data-creation");
      const trackEvents = {
        inputValueAccess: inputValueAccessCheckbox?.checked || false,
        inputEvents: inputEventsCheckbox?.checked || false,
        formSubmit: formSubmitCheckbox?.checked || false,
        formDataCreation: formDataCreationCheckbox?.checked || false
      };
      this.updateState({ trackEvents });
      chrome.runtime.sendMessage({
        type: "SET_TRACK_EVENTS",
        trackEvents
      });
    }
    updateState(newState) {
      this.state = { ...this.state, ...newState };
      this.throttledUpdateUI();
    }
    /**
     * Throttled UI update to prevent excessive DOM operations
     */
    throttledUpdateUI() {
      if (this.isLoading) {
        return;
      }
      const now = Date.now();
      const lastUpdate = this.updateThrottle.get("ui") || 0;
      if (now - lastUpdate >= this.updateInterval) {
        this.updateUI();
        this.updateThrottle.set("ui", now);
        this.pendingUpdate = false;
      } else if (!this.pendingUpdate) {
        this.pendingUpdate = true;
        const timeToWait = this.updateInterval - (now - lastUpdate);
        setTimeout(() => {
          if (this.pendingUpdate && !this.isLoading) {
            this.updateUI();
            this.updateThrottle.set("ui", Date.now());
            this.pendingUpdate = false;
          }
        }, timeToWait);
      }
    }
    updateUI() {
      const hudContent = this.hudElement.querySelector(".hud-content");
      const hudHeader = this.hudElement.querySelector(".hud-header");
      const hudMinimized = this.hudElement.querySelector(".hud-minimized");
      const minimizeToggle = this.hudElement.querySelector(".minimize-toggle");
      if (this.state.minimized) {
        hudContent.style.display = "none";
        hudHeader.style.display = "none";
        hudMinimized.style.display = "block";
        minimizeToggle.textContent = "\u25A1";
        minimizeToggle.title = "Restore HUD";
        this.hudElement.style.width = "50px";
        this.hudElement.style.height = "50px";
        this.hudElement.style.borderRadius = "50%";
        this.hudElement.style.overflow = "visible";
        this.hudElement.style.background = "transparent";
        this.hudElement.style.border = "none";
        this.hudElement.style.boxShadow = "none";
        this.positionAtBottomRight();
      } else {
        hudContent.style.display = "block";
        hudHeader.style.display = "flex";
        hudMinimized.style.display = "none";
        minimizeToggle.textContent = "\u2212";
        minimizeToggle.title = "Minimize HUD";
        this.hudElement.style.width = "350px";
        this.hudElement.style.height = "auto";
        this.hudElement.style.borderRadius = "8px";
        this.hudElement.style.overflow = "hidden";
        this.hudElement.style.background = "";
        this.hudElement.style.border = "";
        this.hudElement.style.boxShadow = "";
      }
      const recordingStatus = this.hudElement.querySelector(".recording-status");
      const windowContext = this.hudElement.querySelector(".window-context");
      const eventCount = this.hudElement.querySelector(".event-count");
      const startBtn = this.hudElement.querySelector(".start-recording");
      const stopBtn = this.hudElement.querySelector(".stop-recording");
      const exportBtn = this.hudElement.querySelector(".export-data");
      const clearBtn = this.hudElement.querySelector(".clear-data");
      recordingStatus.textContent = this.state.recording ? "Recording this window..." : "Not recording";
      recordingStatus.style.color = this.state.recording ? "#4CAF50" : "#666";
      if (windowContext) {
        windowContext.textContent = this.state.recording ? "All tabs in this window are being monitored" : "Window-based recording session ready";
        windowContext.style.color = "#888";
        windowContext.style.fontSize = "12px";
      }
      eventCount.textContent = `Events captured: ${this.state.eventCount}`;
      if (this.state.atCap) {
        eventCount.textContent += " (at cap - oldest events dropped)";
        eventCount.style.color = "#FF9800";
      } else {
        eventCount.style.color = "#666";
      }
      startBtn.disabled = this.state.recording;
      stopBtn.disabled = !this.state.recording;
      exportBtn.disabled = this.state.eventCount === 0 || this.state.recording;
      clearBtn.disabled = this.state.eventCount === 0;
      const toggleSwitch = this.hudElement.querySelector(".toggle-switch");
      const leftLabel = this.hudElement.querySelector(".toggle-label.left");
      const rightLabel = this.hudElement.querySelector(".toggle-label.right");
      if (toggleSwitch && leftLabel && rightLabel) {
        toggleSwitch.setAttribute("data-mode", this.state.recordingMode);
        if (this.state.recordingMode === "console") {
          leftLabel.classList.add("active");
          rightLabel.classList.remove("active");
        } else {
          leftLabel.classList.remove("active");
          rightLabel.classList.add("active");
        }
      }
      const elementSelectorInput = this.hudElement.querySelector(".element-selector");
      const attributeFiltersInput = this.hudElement.querySelector(".attribute-filters");
      const stackKeywordFilterInput = this.hudElement.querySelector(".stack-keyword-filter");
      if (elementSelectorInput) {
        elementSelectorInput.value = this.state.filters.elementSelector;
      }
      if (attributeFiltersInput) {
        attributeFiltersInput.value = this.state.filters.attributeFilters;
      }
      if (stackKeywordFilterInput) {
        stackKeywordFilterInput.value = this.state.filters.stackKeywordFilter;
      }
      const inputValueAccessCheckbox = this.hudElement.querySelector(".input-value-access");
      const inputEventsCheckbox = this.hudElement.querySelector(".input-events");
      const formSubmitCheckbox = this.hudElement.querySelector(".form-submit");
      const formDataCreationCheckbox = this.hudElement.querySelector(".form-data-creation");
      if (inputValueAccessCheckbox) {
        inputValueAccessCheckbox.checked = this.state.trackEvents.inputValueAccess;
      }
      if (inputEventsCheckbox) {
        inputEventsCheckbox.checked = this.state.trackEvents.inputEvents;
      }
      if (formSubmitCheckbox) {
        formSubmitCheckbox.checked = this.state.trackEvents.formSubmit;
      }
      if (formDataCreationCheckbox) {
        formDataCreationCheckbox.checked = this.state.trackEvents.formDataCreation;
      }
      this.hudElement.setAttribute("data-theme", this.state.theme);
      const themeToggle = this.hudElement.querySelector(".theme-toggle");
      if (themeToggle) {
        const moonIcon = themeToggle.querySelector(".moon-icon");
        const sunIcon = themeToggle.querySelector(".sun-icon");
        if (this.state.theme === "dark") {
          moonIcon.style.display = "block";
          sunIcon.style.display = "none";
          themeToggle.title = "Switch to light theme";
        } else {
          moonIcon.style.display = "none";
          sunIcon.style.display = "block";
          themeToggle.title = "Switch to dark theme";
        }
      }
    }
    showMessage(message, level = "info") {
      if (this.exportPreviewShown) {
        return;
      }
      if (this.messageHideTimeout !== null) {
        clearTimeout(this.messageHideTimeout);
        this.messageHideTimeout = null;
      }
      const messageDiv = this.hudElement.querySelector(".message-display");
      messageDiv.textContent = message;
      messageDiv.style.display = "block";
      messageDiv.className = `message-display message-${level}`;
      messageDiv.style.whiteSpace = "normal";
      messageDiv.style.wordWrap = "break-word";
      messageDiv.style.overflowWrap = "break-word";
      messageDiv.style.direction = "auto";
      messageDiv.style.textAlign = "start";
      messageDiv.style.unicodeBidi = "plaintext";
      this.messageHideTimeout = window.setTimeout(() => {
        if (!this.exportPreviewShown) {
          messageDiv.style.display = "none";
        } else {
        }
        this.messageHideTimeout = null;
      }, 3e3);
    }
    makeDraggable() {
      const header = this.hudElement.querySelector(".hud-header");
      let isDragging = false;
      let startX = 0;
      let startY = 0;
      let startLeft = 0;
      let startTop = 0;
      header.addEventListener("mousedown", (e) => {
        isDragging = true;
        startX = e.clientX;
        startY = e.clientY;
        const rect = this.hudElement.getBoundingClientRect();
        startLeft = rect.left;
        startTop = rect.top;
        e.preventDefault();
      });
      document.addEventListener("mousemove", (e) => {
        if (!isDragging) return;
        const deltaX = e.clientX - startX;
        const deltaY = e.clientY - startY;
        let newLeft = startLeft + deltaX;
        let newTop = startTop + deltaY;
        const hudRect = this.hudElement.getBoundingClientRect();
        const maxLeft = window.innerWidth - hudRect.width;
        const maxTop = window.innerHeight - hudRect.height;
        newLeft = Math.max(0, Math.min(newLeft, maxLeft));
        newTop = Math.max(0, Math.min(newTop, maxTop));
        this.hudElement.style.left = newLeft + "px";
        this.hudElement.style.top = newTop + "px";
        this.hudElement.style.right = "auto";
      });
      document.addEventListener("mouseup", () => {
        isDragging = false;
      });
    }
  };
  function waitForDomRoot() {
    return new Promise((resolve) => {
      const root = document.head || document.documentElement || document.body;
      if (root) return resolve(root);
      const observer = new MutationObserver(() => {
        const r = document.head || document.documentElement || document.body;
        if (r) {
          observer.disconnect();
          resolve(r);
        }
      });
      observer.observe(document, { childList: true, subtree: true });
    });
  }
  function injectSurveillanceScript() {
    return new Promise(async (resolve, reject) => {
      try {
        const root = await waitForDomRoot();
        const surveillanceScript = document.createElement("script");
        surveillanceScript.src = chrome.runtime.getURL("injected.js");
        surveillanceScript.onload = () => {
          console.debug("[ContentScript] Surveillance script loaded");
          surveillanceScript.remove();
          resolve();
        };
        surveillanceScript.onerror = () => reject(new Error("Failed to load injected surveillance script"));
        root.appendChild(surveillanceScript);
      } catch (e) {
        reject(e);
      }
    });
  }
  function setupInjectedScriptBridge() {
    window.addEventListener("message", (event) => {
      if (event.source !== window) return;
      if (event.data.type === "EVIDENCE_EVENT") {
        if (!chrome.runtime?.id) {
          console.warn("[ContentScript] Extension context invalidated - cannot send evidence");
          return;
        }
        chrome.runtime.sendMessage({
          type: "EVIDENCE_EVENT",
          event: event.data.event
        }).catch((error) => {
          console.error("[ContentScript] Failed to forward evidence to background:", error);
        });
      }
      if (event.data.type === "EVIDENCE_EVENT_BATCH") {
        if (!chrome.runtime?.id) {
          console.warn("[ContentScript] Extension context invalidated - cannot send evidence batch");
          return;
        }
        console.debug(`[ContentScript] Received evidence batch with ${event.data.batchSize} events`);
        chrome.runtime.sendMessage({
          type: "EVIDENCE_EVENT_BATCH",
          events: event.data.events,
          batchSize: event.data.batchSize
        }).catch((error) => {
          console.error("[ContentScript] Failed to forward evidence batch to background:", error);
        });
      }
      if (event.data.type === "MAIN_WORLD_EVIDENCE_EVENT") {
        if (!chrome.runtime?.id) {
          console.warn("[ContentScript] Extension context invalidated - cannot send main world evidence");
          return;
        }
        console.debug("[ContentScript] Received main world evidence:", {
          actionId: event.data.event.actionId,
          type: event.data.event.type,
          stackTrace: event.data.event.stackTrace,
          stackFrameCount: event.data.event.stackTrace?.length || 0
        });
        chrome.runtime.sendMessage({
          type: "EVIDENCE_EVENT",
          event: event.data.event
        }).catch((error) => {
          console.error("[ContentScript] Failed to forward main world evidence to background:", error);
        });
        console.debug("[ContentScript] Forwarded main world evidence to background");
      }
      if (event.data.type === "INJECTED_SCRIPT_READY") {
        console.debug("[ContentScript] Injected script ready, sending handshake");
        window.postMessage({ type: "CONTENT_SCRIPT_READY" }, "*");
        resyncStateFromBackground();
      }
    });
    console.debug("[ContentScript] Injected script bridge set up");
  }
  function resyncStateFromBackground() {
    console.debug("[ContentScript] Starting state resync from background...");
    chrome.runtime.sendMessage({ type: "GET_STATUS" }, (response) => {
      console.debug("[ContentScript] Received GET_STATUS response:", response);
      if (!response) {
        console.warn("[ContentScript] No response from background script during resync");
        return;
      }
      console.debug("[ContentScript] About to send to injected script:", {
        filters: response.filters,
        recordingMode: response.recordingMode,
        recording: response.recording,
        trackEvents: response.trackEvents,
        fallbackRecordingMode: response.recordingMode || "console"
      });
      setTimeout(() => {
        window.postMessage({ type: "SET_FILTERS", filters: response.filters || { elementSelector: "", attributeFilters: "", stackKeywordFilter: "" } }, "*");
        if (response.recordingMode) {
          console.debug(`[ContentScript] Sending valid recording mode: ${response.recordingMode}`);
          window.postMessage({ type: "SET_RECORDING_MODE", recordingMode: response.recordingMode }, "*");
        } else {
          console.error("[ContentScript] \u274C CRITICAL: Background returned no recordingMode!", {
            fullResponse: response,
            backgroundMightBeCorrupted: true
          });
          console.warn("[ContentScript] Force-resetting to console mode due to missing recordingMode");
          window.postMessage({ type: "SET_RECORDING_MODE", recordingMode: "console" }, "*");
        }
        window.postMessage({ type: "SET_RECORDING_STATE", recording: !!response.recording }, "*");
        window.postMessage({ type: "SET_TRACK_EVENTS", trackEvents: response.trackEvents || { inputValueAccess: true, inputEvents: true, formSubmit: true, formDataCreation: true } }, "*");
        console.debug("[ContentScript] State messages sent to injected script");
        setTimeout(() => validateStateSync(), 500);
      }, 0);
    });
  }
  function validateStateSync() {
    const hudElement = document.getElementById("evidence-hud-overlay");
    const toggleSwitch = hudElement?.querySelector(".toggle-switch");
    const hudRecordingMode = toggleSwitch?.getAttribute("data-mode") || "unknown";
    console.debug("[ContentScript] Reading HUD state for validation:", {
      hudElementExists: !!hudElement,
      toggleSwitchExists: !!toggleSwitch,
      dataMode: toggleSwitch?.getAttribute("data-mode"),
      resolvedMode: hudRecordingMode
    });
    window.postMessage({ type: "GET_INJECTED_STATE" }, "*");
    const stateValidator = (event) => {
      if (event.source !== window || event.data.type !== "INJECTED_STATE_RESPONSE") return;
      const injectedState = event.data.state;
      console.debug("[ContentScript] State validation:", {
        hudRecordingMode,
        injectedRecordingMode: injectedState.recordingMode,
        injectedRecording: injectedState.recording,
        inSync: hudRecordingMode === injectedState.recordingMode
      });
      if (hudRecordingMode !== injectedState.recordingMode) {
      } else {
        console.debug("[ContentScript] \u2705 State is synchronized");
      }
      window.removeEventListener("message", stateValidator);
    };
    window.addEventListener("message", stateValidator);
    setTimeout(() => window.removeEventListener("message", stateValidator), 1e3);
  }
  function setupControlForwarding() {
    chrome.runtime.onMessage.addListener((message) => {
      switch (message.type) {
        case "SET_RECORDING_MODE":
          window.postMessage({
            type: "SET_RECORDING_MODE",
            recordingMode: message.recordingMode
          }, "*");
          break;
        case "SET_RECORDING_STATE":
          window.postMessage({
            type: "SET_RECORDING_STATE",
            recording: message.recording
          }, "*");
          break;
        case "SET_FILTERS":
          window.postMessage({
            type: "SET_FILTERS",
            filters: message.filters
          }, "*");
          break;
        case "SET_TRACK_EVENTS":
          window.postMessage({
            type: "SET_TRACK_EVENTS",
            trackEvents: message.trackEvents
          }, "*");
          break;
      }
    });
  }
  var isInitialized = false;
  var hudInstance = null;
  async function initialize() {
    if (isInitialized) {
      console.warn("[ContentScript] \u26A0\uFE0F initialize() called multiple times! Skipping to prevent duplicate HUD.");
      return;
    }
    console.debug("[ContentScript] Initializing Reflectiz content script...");
    try {
      await injectSurveillanceScript();
      setupInjectedScriptBridge();
      setupControlForwarding();
      if (window === window.top) {
        const existingHUD = document.getElementById("evidence-hud-overlay");
        if (existingHUD) {
          console.warn("[ContentScript] \u26A0\uFE0F HUD element already exists in DOM! Removing old one.");
          existingHUD.remove();
        }
        hudInstance = new HUD();
        console.debug("[ContentScript] \u2705 HUD initialized in main frame");
      } else {
        console.debug("[ContentScript] Skipping HUD in iframe");
      }
      isInitialized = true;
      console.debug("[ContentScript] \u2705 Content script initialization complete");
    } catch (error) {
      console.error("[ContentScript] Failed to initialize:", error);
    }
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initialize);
  } else {
    initialize();
  }
})();
