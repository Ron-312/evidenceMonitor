"use strict";
(() => {
  // src/scripts/state/track-events-manager.ts
  var TrackEventsManager = class {
    constructor() {
      this.trackEventsState = {
        inputValueAccess: true,
        inputEvents: true,
        formSubmit: true,
        formDataCreation: true
      };
    }
    /**
     * Updates the track events configuration from HUD
     */
    setTrackEvents(trackEvents) {
      this.trackEventsState = { ...trackEvents };
      console.debug("[TrackEventsManager] Track events updated:", trackEvents);
    }
    /**
     * Returns current track events state
     */
    getTrackEvents() {
      return { ...this.trackEventsState };
    }
    /**
     * Checks if Input Value Access tracking is enabled
     * Controls property getter hooks (input.value, textarea.value, etc.)
     */
    isInputValueAccessEnabled() {
      return this.trackEventsState.inputValueAccess;
    }
    /**
     * Checks if Input Events tracking is enabled
     * Controls addEventListener hooks for keydown, input, change, etc.
     */
    isInputEventsEnabled() {
      return this.trackEventsState.inputEvents;
    }
    /**
     * Checks if Form Submit tracking is enabled
     * Controls form.submit() method hooks and submit event listeners
     */
    isFormSubmitEnabled() {
      return this.trackEventsState.formSubmit;
    }
    /**
     * Checks if FormData Creation tracking is enabled
     * Controls FormData constructor hooks (new FormData())
     */
    isFormDataCreationEnabled() {
      return this.trackEventsState.formDataCreation;
    }
    /**
     * Gets current statistics for debugging
     */
    getStats() {
      const enabled = Object.values(this.trackEventsState).filter(Boolean).length;
      const total = Object.keys(this.trackEventsState).length;
      return {
        trackEventsState: this.getTrackEvents(),
        enabledCount: enabled,
        totalCategories: total
      };
    }
  };
  var trackEventsManager = new TrackEventsManager();

  // src/scripts/config/evidence-config.ts
  var EVIDENCE_CONFIG = {
    // HTMLInputElement, HTMLSelectElement, HTMLTextAreaElement hooks
    formElements: {
      elements: ["input", "select", "textarea"],
      // Property getters to hook (when scripts READ values)
      propertyGetters: [
        "value",
        // Most common - input.value, select.value, textarea.value
        "nodeValue"
        // Alternative access pattern - element.nodeValue
      ],
      // Event handler property setters (when scripts SET event handlers)
      eventHandlerSetters: [
        "onkeydown",
        // element.onkeydown = handler
        "onkeypress",
        // element.onkeypress = handler
        "onkeyup",
        // element.onkeyup = handler
        "oninput",
        // element.oninput = handler
        "onchange"
        // element.onchange = handler
      ],
      // addEventListener calls to monitor
      eventListeners: [
        "keydown",
        // element.addEventListener('keydown', handler)
        "keypress",
        // element.addEventListener('keypress', handler)
        "keyup",
        // element.addEventListener('keyup', handler)
        "input",
        // element.addEventListener('input', handler)
        "change"
        // element.addEventListener('change', handler)
      ]
    },
    // Form submission surveillance (matches Explorer pattern)
    formSubmission: {
      elements: ["form"],
      // HTMLFormElement
      methods: ["submit"],
      // form.submit() method
      eventListeners: ["submit"]
      // form.addEventListener('submit', handler)
    },
    // FormData creation surveillance (matches Explorer pattern)
    formDataCreation: {
      constructor: "FormData"
      // new FormData() constructor
    }
  };
  function isFormElement(element) {
    return EVIDENCE_CONFIG.formElements.elements.some(
      (tag) => element.tagName.toLowerCase() === tag
    );
  }
  function generateEvidenceType(target, action, hookType) {
    let targetName;
    if (target instanceof Element) {
      targetName = target.tagName.toLowerCase();
    } else {
      targetName = "unknown";
    }
    switch (hookType) {
      case "property":
        return `${targetName}.${action}/get`;
      case "eventHandler":
        return `${targetName}.${action}/set`;
      case "addEventListener":
        return `${targetName}.addEventListener(${action})`;
      default:
        return `${targetName}.${action}`;
    }
  }

  // src/scripts/utils/stack-trace.ts
  var StackTrace = class {
    /**
     * Captures current call stack and formats for evidence
     * Returns array of formatted stack frames matching Explorer format
     */
    static capture() {
      try {
        const error = new Error();
        const stack = error.stack;
        if (!stack || typeof stack !== "string") {
          throw new Error("Stack trace is empty or invalid");
        }
        return this.parseAndFormat(stack);
      } catch (captureError) {
        console.error("[StackTrace] Failed to capture stack trace:", captureError);
        return ["[STACK_TRACE_CAPTURE_FAILED]"];
      }
    }
    /**
     * Parses raw stack trace string and formats to Explorer-compatible array
     */
    static parseAndFormat(stackString) {
      try {
        const lines = stackString.split("\n");
        const formattedFrames = [];
        for (const line of lines) {
          if (line.trim() === "" || line.trim() === "Error") {
            continue;
          }
          const parsedFrame = this.parseStackFrame(line.trim());
          if (parsedFrame && this.shouldIncludeFrame(parsedFrame)) {
            const formattedFrame = this.formatFrame(parsedFrame);
            if (formattedFrame) {
              formattedFrames.push(formattedFrame);
            }
          }
        }
        return formattedFrames.length > 0 ? formattedFrames : ["[NO_VALID_STACK_FRAMES]"];
      } catch (parseError) {
        console.error("[StackTrace] Failed to parse stack trace:", parseError);
        return ["[STACK_TRACE_PARSE_FAILED]"];
      }
    }
    /**
     * Parses individual stack frame line into components
     * Handles various browser stack trace formats
     */
    static parseStackFrame(frame) {
      try {
        const cleanFrame = frame.replace(/^\s*at\s+/, "");
        let match = cleanFrame.match(/^(.+?)\s+\((.+?):(\d+):(\d+)\)$/);
        if (match) {
          const [, functionName, url, line, column] = match;
          return {
            url: url.trim(),
            line: parseInt(line, 10),
            column: parseInt(column, 10),
            functionName: functionName.trim()
          };
        }
        match = cleanFrame.match(/^(.+?):(\d+):(\d+)$/);
        if (match) {
          const [, url, line, column] = match;
          return {
            url: url.trim(),
            line: parseInt(line, 10),
            column: parseInt(column, 10)
          };
        }
        match = cleanFrame.match(/^(.+?)\s+\(eval\s+at\s+.+?\((.+?):(\d+):(\d+)\)/);
        if (match) {
          const [, functionName, url, line, column] = match;
          return {
            url: url.trim(),
            line: parseInt(line, 10),
            column: parseInt(column, 10),
            functionName: `${functionName.trim()} [eval]`
          };
        }
        return null;
      } catch (error) {
        return null;
      }
    }
    /**
     * Determines if stack frame should be included in evidence
     * Uses smart blacklist filtering to exclude noise while preserving attack evidence
     */
    static shouldIncludeFrame(frame) {
      const isOurExtension = frame.url.includes("chrome-extension://") && (frame.url.includes("injected.js") || frame.url.includes("content.js") || frame.url.includes("background.js") || frame.url.includes("main-world-hooks.js") || frame.url.includes("shared-types.js"));
      if (isOurExtension) {
        return false;
      }
      const isBrowserInternal = frame.url.startsWith("about:config") || frame.url.startsWith("about:chrome") || frame.url.startsWith("about:debugging") || frame.url.startsWith("about:preferences") || frame.url.startsWith("about:memory") || frame.url.startsWith("about:support") || frame.url.startsWith("chrome://") || frame.url.startsWith("edge://") || frame.url.startsWith("firefox://");
      if (isBrowserInternal) {
        return false;
      }
      if (!frame.url || frame.url.trim() === "" || frame.url === "null" || frame.url === "undefined") {
        return false;
      }
      return true;
    }
    /**
     * Formats parsed frame to Explorer format: "URL:line:col [functionName]"
     */
    static formatFrame(frame) {
      try {
        const baseFormat = `${frame.url}:${frame.line}:${frame.column}`;
        if (frame.functionName && this.isMeaningfulFunctionName(frame.functionName)) {
          return `${baseFormat} [${frame.functionName}]`;
        }
        return baseFormat;
      } catch (error) {
        return null;
      }
    }
    /**
     * Checks if function name should be included in stack trace
     */
    static isMeaningfulFunctionName(functionName) {
      if (!functionName || functionName.trim() === "") {
        return false;
      }
      return true;
    }
    /**
     * Utility method for testing - captures stack with known depth
     */
    static captureWithContext(context) {
      const frames = this.capture();
      if (frames.length > 0 && !frames[0].includes("FAILED")) {
        console.debug(`[StackTrace] Captured ${frames.length} frames for context: ${context}`);
      }
      return frames;
    }
  };
  // Anonymous function patterns to ignore
  StackTrace.ANONYMOUS_PATTERNS = [
    "<anonymous>",
    "Object.<anonymous>",
    "anonymous"
  ];

  // src/scripts/main-world-hooks.ts
  var elementIdCounter = 0;
  var elementIdMap = /* @__PURE__ */ new WeakMap();
  function getElementId(element) {
    if (!elementIdMap.has(element)) {
      const id = "mw" + Date.now().toString(36) + (++elementIdCounter).toString(36);
      elementIdMap.set(element, id);
    }
    return elementIdMap.get(element);
  }
  function captureStackTrace() {
    return StackTrace.capture();
  }
  function shouldMonitorEventListener(target, eventType) {
    if (!(target instanceof Element)) {
      return false;
    }
    if (!isFormElement(target)) {
      return false;
    }
    if (!EVIDENCE_CONFIG.formElements.eventListeners.includes(eventType)) {
      return false;
    }
    return true;
  }
  function getElementData(element) {
    try {
      const tagName = element.tagName.toLowerCase();
      const attributes = [];
      const keyAttrs = ["id", "class", "name", "type", "value", "placeholder"];
      for (const attr of keyAttrs) {
        const value = element.getAttribute(attr);
        if (value !== null) {
          attributes.push(`${attr}="${value}"`);
        }
      }
      return `<${tagName}${attributes.length > 0 ? " " + attributes.join(" ") : ""}>`;
    } catch (error) {
      return `<${element.tagName.toLowerCase()}>`;
    }
  }
  function generateActionId() {
    return Math.random().toString(36).substring(2) + Date.now().toString(36);
  }
  (function installMainWorldHooks() {
    if (window.__REFLECTIZ_MAIN_WORLD_HOOKS__) {
      return;
    }
    try {
      console.debug("[MainWorldHooks] Installing addEventListener hook at document_start");
      const originalAddEventListener = EventTarget.prototype.addEventListener;
      window.__ORIGINAL_ADD_EVENT_LISTENER__ = originalAddEventListener;
      EventTarget.prototype.addEventListener = function(type, listener, options) {
        if (type === "addEventListener") {
          const debugData = {
            actionId: `DEBUG_MW_RECURSIVE_${Date.now()}`,
            type: "DEBUG.recursiveCall",
            start: performance.now(),
            duration: 0,
            data: `[MAIN_WORLD RECURSIVE] addEventListener("${type}") on ${this instanceof Element ? this.tagName : "non-Element"}`,
            target: { id: `debug-${Date.now()}` },
            stackTrace: new Error().stack?.split("\n").slice(1, 6) || ["[NO_STACK]"]
          };
          window.postMessage({
            type: "MAIN_WORLD_EVIDENCE_EVENT",
            event: debugData
          }, "*");
          console.error("[MainWorldHooks] \u{1F6A8} MAIN WORLD RECURSIVE CALL - logged to JSON");
        }
        if (shouldMonitorEventListener(this, type)) {
          try {
            const element = this;
            const elementId = getElementId(element);
            const stackTrace = captureStackTrace();
            const elementData = getElementData(element);
            const evidenceType = generateEvidenceType(element, type, "addEventListener");
            const evidenceEvent = {
              actionId: generateActionId(),
              type: evidenceType,
              start: performance.now(),
              duration: 0,
              data: `${elementData}`,
              target: { id: elementId },
              stackTrace
            };
            window.postMessage({
              type: "MAIN_WORLD_EVIDENCE_EVENT",
              event: evidenceEvent
            }, "*");
          } catch (error) {
            console.error("[MainWorldHooks] Error capturing addEventListener evidence:", error);
          }
        }
        return originalAddEventListener.call(this, type, listener, options);
      };
      window.__REFLECTIZ_MAIN_WORLD_HOOKS__ = true;
      console.debug("[MainWorldHooks] addEventListener hook installed successfully");
    } catch (error) {
      console.error("[MainWorldHooks] Failed to install addEventListener hook:", error);
    }
  })();
})();
