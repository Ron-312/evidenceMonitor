class EvidenceManager {
    constructor() {
        this.EVENT_CAP = 5000;
        this.tabData = new Map();
        this.tabStorageKeys = new Map();
        this.setupMessageHandlers();
        this.setupTabHandlers();
        this.cleanupOldStates();
    }
    setupMessageHandlers() {
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            const tabId = sender.tab?.id;
            if (!tabId)
                return;
            switch (message.type) {
                case 'EVIDENCE_EVENT':
                    if (message.event && sender.tab?.url) {
                        this.addEvent(tabId, message.event, sender.tab.url);
                    }
                    break;
                case 'TOGGLE_RECORDING':
                    if (sender.tab?.url) {
                        this.toggleRecording(tabId, sender.tab.url).then(() => {
                            sendResponse({ recording: this.isRecording(tabId) });
                        });
                        return true;
                    }
                    break;
                case 'GET_STATUS':
                    if (sender.tab?.url) {
                        this.initializeTab(tabId, sender.tab.url).then(() => {
                            const statusResponse = {
                                recording: this.isRecording(tabId),
                                eventCount: this.getEventCount(tabId),
                                atCap: this.isAtCap(tabId),
                                recordingMode: this.getRecordingMode(tabId),
                                filters: this.getFilters(tabId),
                                trackEvents: this.getTrackEvents(tabId)
                            };
                            if (!statusResponse.recordingMode) {
                                console.error(`[Background] ❌ CRITICAL: No recordingMode for tab ${tabId}! Forcing console mode.`, {
                                    tabExists: this.tabData.has(tabId),
                                    tabData: this.tabData.get(tabId)
                                });
                                statusResponse.recordingMode = 'console';
                            }
                            console.debug(`[Background] GET_STATUS response for tab ${tabId}:`, statusResponse);
                            sendResponse(statusResponse);
                        }).catch(error => {
                            console.error(`[Background] Failed to initialize tab ${tabId}:`, error);
                            sendResponse({
                                recording: false,
                                eventCount: 0,
                                atCap: false,
                                recordingMode: 'console',
                                filters: { elementSelector: '', attributeFilters: '', stackKeywordFilter: '' },
                                trackEvents: { inputValueAccess: true, inputEvents: true, formSubmit: true, formDataCreation: true }
                            });
                        });
                        return true;
                    }
                    break;
                case 'EXPORT_EVENTS':
                    this.exportEvents(tabId);
                    sendResponse({ exported: true });
                    break;
                case 'CLEAR_EVENTS':
                    this.clearEvents(tabId).then(() => {
                        sendResponse({ cleared: true });
                    });
                    return true;
                    break;
                case 'SET_RECORDING_MODE':
                    if (message.recordingMode) {
                        this.setRecordingMode(tabId, message.recordingMode).then(() => {
                            sendResponse({ recordingMode: message.recordingMode });
                        });
                        return true;
                    }
                    break;
                case 'SET_FILTERS':
                    if (message.filters && sender.tab?.url) {
                        this.setFilters(tabId, message.filters, sender.tab.url).then(() => {
                            sendResponse({ filters: message.filters });
                        });
                        return true;
                    }
                    break;
                case 'SET_TRACK_EVENTS':
                    if (message.trackEvents && sender.tab?.url) {
                        this.setTrackEvents(tabId, message.trackEvents, sender.tab.url).then(() => {
                            sendResponse({ trackEvents: message.trackEvents });
                        });
                        return true;
                    }
                    break;
            }
        });
    }
    setupTabHandlers() {
        chrome.tabs.onRemoved.addListener((tabId) => {
            if (this.tabData.has(tabId) && this.isRecording(tabId)) {
                console.log(`Tab ${tabId} closed with recording enabled - auto-exporting`);
                this.exportEvents(tabId, true);
            }
            this.tabData.delete(tabId);
            this.tabStorageKeys.delete(tabId);
            console.debug(`[Background] Cleaned up tab ${tabId} data and storage key`);
        });
    }
    async initializeTab(tabId, url) {
        if (!this.tabData.has(tabId)) {
            const domain = new URL(url).hostname;
            const savedState = await this.loadTabState(domain);
            let storageKey = this.tabStorageKeys.get(tabId);
            if (!storageKey) {
                storageKey = this.generateStorageKey(domain);
                this.tabStorageKeys.set(tabId, storageKey);
            }
            const tabData = {
                events: [],
                recording: savedState?.recording ?? false,
                recordingMode: savedState?.recordingMode ?? 'console',
                domain: domain,
                createdAt: Date.now(),
                filters: savedState?.filters ?? {
                    elementSelector: '',
                    attributeFilters: '',
                    stackKeywordFilter: ''
                },
                trackEvents: savedState?.trackEvents ?? {
                    inputValueAccess: true,
                    inputEvents: true,
                    formSubmit: true,
                    formDataCreation: true
                }
            };
            this.tabData.set(tabId, tabData);
            await this.saveTabState(tabId);
            console.debug(`[Background] Initialized tab ${tabId} for domain ${domain}${savedState ? ' with saved state' : ' with defaults'}`);
        }
    }
    async addEvent(tabId, event, url) {
        await this.initializeTab(tabId, url);
        const tabInfo = this.tabData.get(tabId);
        if (!tabInfo.recording)
            return;
        if (!event.start) {
            event.start = performance.now();
        }
        tabInfo.events.push(event);
        if (tabInfo.events.length >= this.EVENT_CAP) {
            this.sendToTab(tabId, {
                type: 'HUD_MESSAGE',
                level: 'warning',
                message: `Event cap reached (${this.EVENT_CAP}). Oldest events will be dropped.`
            });
            tabInfo.events = tabInfo.events.slice(-this.EVENT_CAP);
        }
        this.sendToTab(tabId, {
            type: 'HUD_UPDATE',
            eventCount: tabInfo.events.length,
            atCap: tabInfo.events.length >= this.EVENT_CAP
        });
    }
    async toggleRecording(tabId, url) {
        await this.initializeTab(tabId, url);
        const tabInfo = this.tabData.get(tabId);
        tabInfo.recording = !tabInfo.recording;
        this.sendToTab(tabId, {
            type: 'HUD_UPDATE',
            recording: tabInfo.recording,
            eventCount: tabInfo.events.length
        });
        if (tabInfo.recording) {
            this.sendToTab(tabId, {
                type: 'HUD_MESSAGE',
                level: 'info',
                message: 'Recording started - watching input interactions'
            });
            this.sendToTab(tabId, {
                type: 'SET_RECORDING_MODE',
                recordingMode: tabInfo.recordingMode
            });
        }
        else {
            this.sendToTab(tabId, {
                type: 'HUD_MESSAGE',
                level: 'info',
                message: 'Recording stopped'
            });
        }
        this.sendToTab(tabId, {
            type: 'SET_RECORDING_STATE',
            recording: tabInfo.recording
        });
        await this.saveTabState(tabId);
    }
    isRecording(tabId) {
        return this.tabData.get(tabId)?.recording || false;
    }
    getEventCount(tabId) {
        return this.tabData.get(tabId)?.events.length || 0;
    }
    isAtCap(tabId) {
        return this.getEventCount(tabId) >= this.EVENT_CAP;
    }
    getRecordingMode(tabId) {
        const tabInfo = this.tabData.get(tabId);
        const mode = tabInfo?.recordingMode || 'console';
        console.debug(`[Background] getRecordingMode(${tabId}):`, {
            tabExists: !!tabInfo,
            storedMode: tabInfo?.recordingMode,
            returnedMode: mode,
            domain: tabInfo?.domain
        });
        return mode;
    }
    async setRecordingMode(tabId, mode) {
        const tabInfo = this.tabData.get(tabId);
        if (tabInfo) {
            tabInfo.recordingMode = mode;
            console.debug(`[Background] Recording mode set to ${mode} for tab ${tabId}`);
            this.sendToTab(tabId, {
                type: 'SET_RECORDING_MODE',
                recordingMode: mode
            });
            await this.saveTabState(tabId);
        }
    }
    getFilters(tabId) {
        return this.tabData.get(tabId)?.filters || {
            elementSelector: '',
            attributeFilters: '',
            stackKeywordFilter: ''
        };
    }
    async setFilters(tabId, filters, url) {
        await this.initializeTab(tabId, url);
        const tabInfo = this.tabData.get(tabId);
        if (tabInfo) {
            tabInfo.filters = filters;
            console.debug(`[Background] Filters updated for tab ${tabId}:`, filters);
            this.sendToTab(tabId, {
                type: 'SET_FILTERS',
                filters: filters
            });
            await this.saveTabState(tabId);
        }
    }
    getTrackEvents(tabId) {
        return this.tabData.get(tabId)?.trackEvents || {
            inputValueAccess: true,
            inputEvents: true,
            formSubmit: true,
            formDataCreation: true
        };
    }
    async setTrackEvents(tabId, trackEvents, url) {
        await this.initializeTab(tabId, url);
        const tabInfo = this.tabData.get(tabId);
        if (tabInfo) {
            tabInfo.trackEvents = trackEvents;
            console.debug(`[Background] Track Events updated for tab ${tabId}:`, trackEvents);
            this.sendToTab(tabId, {
                type: 'SET_TRACK_EVENTS',
                trackEvents: trackEvents
            });
            await this.saveTabState(tabId);
        }
    }
    async clearEvents(tabId) {
        const tabInfo = this.tabData.get(tabId);
        if (tabInfo) {
            tabInfo.events = [];
            this.sendToTab(tabId, {
                type: 'HUD_UPDATE',
                eventCount: 0,
                atCap: false
            });
            this.sendToTab(tabId, {
                type: 'HUD_MESSAGE',
                level: 'info',
                message: 'Events cleared'
            });
            await this.saveTabState(tabId);
        }
    }
    deduplicateEvents(events) {
        const actionMap = new Set();
        const deduplicatedEvents = [];
        for (const event of events) {
            const key = `${event.type}__${event.data}__${event.target.id}`;
            if (!actionMap.has(key)) {
                actionMap.add(key);
                deduplicatedEvents.push(event);
            }
        }
        return {
            deduplicated: deduplicatedEvents,
            originalCount: events.length,
            deduplicatedCount: deduplicatedEvents.length,
            duplicatesRemoved: events.length - deduplicatedEvents.length
        };
    }
    exportEvents(tabId, isAutoExport = false) {
        const tabInfo = this.tabData.get(tabId);
        if (!tabInfo || tabInfo.events.length === 0) {
            if (!isAutoExport) {
                this.sendToTab(tabId, {
                    type: 'HUD_MESSAGE',
                    level: 'warning',
                    message: 'No events to export'
                });
            }
            return;
        }
        const deduplicationResult = this.deduplicateEvents(tabInfo.events);
        const now = new Date();
        const dateStr = now.toISOString().split('T')[0];
        const timeStr = now.toTimeString().split(' ')[0].replace(/:/g, '-');
        const filename = `evidence_${tabInfo.domain}_${dateStr}_${timeStr}.json`;
        const exportData = {
            metadata: {
                domain: tabInfo.domain,
                exportedAt: now.toISOString(),
                eventCount: deduplicationResult.deduplicatedCount,
                recordingStarted: new Date(tabInfo.createdAt).toISOString(),
                autoExported: isAutoExport,
                deduplication: {
                    originalCount: deduplicationResult.originalCount,
                    deduplicatedCount: deduplicationResult.deduplicatedCount,
                    duplicatesRemoved: deduplicationResult.duplicatesRemoved
                }
            },
            events: deduplicationResult.deduplicated
        };
        const jsonString = JSON.stringify(exportData, null, 2);
        const url = 'data:application/json;charset=utf-8,' + encodeURIComponent(jsonString);
        chrome.downloads.download({
            url: url,
            filename: filename,
            saveAs: !isAutoExport
        }, (_downloadId) => {
            if (!isAutoExport) {
                const message = deduplicationResult.duplicatesRemoved > 0
                    ? `Exported ${deduplicationResult.deduplicatedCount} events to ${filename} (${deduplicationResult.duplicatesRemoved} duplicates removed)`
                    : `Exported ${deduplicationResult.deduplicatedCount} events to ${filename}`;
                this.sendToTab(tabId, {
                    type: 'HUD_MESSAGE',
                    level: 'success',
                    message: message
                });
            }
        });
    }
    generateStorageKey(domain) {
        return `tab_${domain}`;
    }
    async saveTabState(tabId) {
        const tabInfo = this.tabData.get(tabId);
        const storageKey = this.tabStorageKeys.get(tabId);
        if (!tabInfo || !storageKey)
            return;
        try {
            const stateToSave = {
                recording: tabInfo.recording,
                recordingMode: tabInfo.recordingMode,
                filters: tabInfo.filters,
                trackEvents: tabInfo.trackEvents,
                domain: tabInfo.domain,
                lastUpdated: Date.now()
            };
            await chrome.storage.local.set({ [storageKey]: stateToSave });
            console.debug(`[Background] Saved state for tab ${tabId} with key ${storageKey}:`, stateToSave);
        }
        catch (error) {
            console.warn(`[Background] Failed to save state for tab ${tabId}:`, error);
        }
    }
    async loadTabState(domain) {
        try {
            const storageKey = `tab_${domain}`;
            const storage = await chrome.storage.local.get(storageKey);
            const state = storage[storageKey];
            console.debug(`[Background] loadTabState for domain ${domain}:`, {
                storageKey,
                foundInStorage: !!state,
                loadedState: state,
                recordingMode: state?.recordingMode
            });
            if (state) {
                return state;
            }
            return null;
        }
        catch (error) {
            console.warn(`[Background] Failed to load state for domain ${domain}:`, error);
            return null;
        }
    }
    async cleanupOldStates() {
        try {
            const storage = await chrome.storage.local.get();
            const keys = Object.keys(storage);
            const now = Date.now();
            const maxAge = 7 * 24 * 60 * 60 * 1000;
            const keysToRemove = keys
                .filter(key => key.startsWith('tab_'))
                .filter(key => {
                const state = storage[key];
                return state && state.lastUpdated && (now - state.lastUpdated) > maxAge;
            });
            if (keysToRemove.length > 0) {
                await chrome.storage.local.remove(keysToRemove);
                console.debug(`[Background] Cleaned up ${keysToRemove.length} old state entries`);
            }
        }
        catch (error) {
            console.warn('[Background] Failed to cleanup old states:', error);
        }
    }
    sendToTab(tabId, message) {
        chrome.tabs.sendMessage(tabId, message).catch(() => {
        });
    }
}
const evidenceManager = new EvidenceManager();
console.log('Input Evidence Extension background service worker initialized');
export {};
