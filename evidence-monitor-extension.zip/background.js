class EvidenceManager {
    constructor() {
        this.EVENT_CAP = 10000;
        this.hudUpdateThrottle = new Map();
        this.hudUpdateInterval = 200;
        this.windowData = new Map();
        this.tabWindowMap = new Map();
        this.setupMessageHandlers();
        this.setupTabHandlers();
        this.setupWindowHandlers();
    }
    normalizeUrlForGrouping(url) {
        try {
            const urlObj = new URL(url);
            let hostname = urlObj.hostname;
            let pathname = urlObj.pathname;
            try {
                hostname = decodeURIComponent(hostname);
                pathname = decodeURIComponent(pathname);
            }
            catch (decodeError) {
                console.warn('[Background] Failed to decode URI components, using original:', decodeError);
            }
            return `${hostname}${pathname}`.replace(/\/$/, '');
        }
        catch (error) {
            console.warn('[Background] Failed to normalize URL:', url, error);
            return 'unknown-url';
        }
    }
    createFilename(normalizedUrl, timestamp) {
        const safeName = normalizedUrl
            .replace(/[<>:"/\\|?*]/g, '_')
            .replace(/[\x00-\x1f]/g, '_')
            .replace(/_{2,}/g, '_')
            .replace(/^_|_$/g, '');
        const dateStr = timestamp.toISOString().split('T')[0];
        const timeStr = timestamp.toTimeString().split(' ')[0].replace(/:/g, '-');
        return `evidence_${safeName}_${dateStr}_${timeStr}.json`;
    }
    async getWindowIdFromTab(tabId) {
        try {
            if (this.tabWindowMap.has(tabId)) {
                return this.tabWindowMap.get(tabId);
            }
            const tab = await chrome.tabs.get(tabId);
            this.tabWindowMap.set(tabId, tab.windowId);
            return tab.windowId;
        }
        catch (error) {
            console.error(`[Background] Failed to get window ID for tab ${tabId}:`, error);
            throw new Error(`Cannot determine window for tab ${tabId}`);
        }
    }
    initializeWindow(windowId) {
        if (!this.windowData.has(windowId)) {
            const windowState = {
                recording: false,
                recordingMode: 'console',
                filters: {
                    elementSelector: '',
                    attributeFilters: '',
                    stackKeywordFilter: ''
                },
                trackEvents: {
                    inputValueAccess: true,
                    inputEvents: true,
                    formSubmit: true,
                    formDataCreation: true
                },
                events: [],
                createdAt: Date.now(),
                tabIds: new Set()
            };
            this.windowData.set(windowId, windowState);
            console.debug(`[Background] Initialized window ${windowId} with default state`);
        }
    }
    addTabToWindow(windowId, tabId) {
        this.initializeWindow(windowId);
        const windowState = this.windowData.get(windowId);
        windowState.tabIds.add(tabId);
        this.tabWindowMap.set(tabId, windowId);
    }
    setupMessageHandlers() {
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            const tabId = sender.tab?.id;
            if (!tabId)
                return;
            switch (message.type) {
                case 'EVIDENCE_EVENT':
                    if (message.event && sender.tab?.url) {
                        this.addEvent(tabId, message.event, sender.tab.url).catch(error => {
                            console.error('[Background] Failed to add evidence event:', error);
                        });
                    }
                    break;
                case 'EVIDENCE_EVENT_BATCH':
                    if (message.events && message.batchSize && sender.tab?.url) {
                        console.debug(`[Background] Processing batch of ${message.batchSize} events from tab ${tabId}`);
                        this.addEventBatch(tabId, message.events, sender.tab.url).catch(error => {
                            console.error('[Background] Failed to add evidence event batch:', error);
                        });
                    }
                    break;
                case 'TOGGLE_RECORDING':
                    this.toggleRecording(tabId).then(() => {
                        sendResponse({ recording: this.isRecording(tabId) });
                    }).catch(error => {
                        console.error('[Background] Failed to toggle recording:', error);
                        sendResponse({ error: 'Failed to toggle recording' });
                    });
                    return true;
                case 'GET_STATUS':
                    this.getWindowIdFromTab(tabId).then(windowId => {
                        this.addTabToWindow(windowId, tabId);
                        const windowState = this.windowData.get(windowId);
                        const statusResponse = {
                            recording: windowState.recording,
                            eventCount: windowState.events.length,
                            atCap: windowState.events.length >= this.EVENT_CAP,
                            recordingMode: windowState.recordingMode,
                            filters: windowState.filters,
                            trackEvents: windowState.trackEvents
                        };
                        console.debug(`[Background] GET_STATUS response for tab ${tabId}, window ${windowId}:`, statusResponse);
                        sendResponse(statusResponse);
                    }).catch(error => {
                        console.error(`[Background] Failed to get status for tab ${tabId}:`, error);
                        sendResponse({
                            recording: false,
                            eventCount: 0,
                            atCap: false,
                            recordingMode: 'console',
                            filters: { elementSelector: '', attributeFilters: '', stackKeywordFilter: '' },
                            trackEvents: { inputValueAccess: true, inputEvents: true, formSubmit: true, formDataCreation: true }
                        });
                    });
                    return true;
                case 'EXPORT_EVENTS':
                    this.exportEvents(tabId).catch(error => {
                        console.error('[Background] Failed to export events:', error);
                        sendResponse({ error: 'Failed to export events' });
                    });
                    sendResponse({ exported: true });
                    break;
                case 'CLEAR_EVENTS':
                    this.clearEvents(tabId).then(() => {
                        sendResponse({ cleared: true });
                    }).catch(error => {
                        console.error('[Background] Failed to clear events:', error);
                        sendResponse({ error: 'Failed to clear events' });
                    });
                    return true;
                case 'SET_RECORDING_MODE':
                    if (message.recordingMode) {
                        this.setRecordingMode(tabId, message.recordingMode).then(() => {
                            sendResponse({ recordingMode: message.recordingMode });
                        }).catch(error => {
                            console.error('[Background] Failed to set recording mode:', error);
                            sendResponse({ error: 'Failed to set recording mode' });
                        });
                        return true;
                    }
                    break;
                case 'SET_FILTERS':
                    if (message.filters) {
                        this.setFilters(tabId, message.filters).then(() => {
                            sendResponse({ filters: message.filters });
                        }).catch(error => {
                            console.error('[Background] Failed to set filters:', error);
                            sendResponse({ error: 'Failed to set filters' });
                        });
                        return true;
                    }
                    break;
                case 'SET_TRACK_EVENTS':
                    if (message.trackEvents) {
                        this.setTrackEvents(tabId, message.trackEvents).then(() => {
                            sendResponse({ trackEvents: message.trackEvents });
                        }).catch(error => {
                            console.error('[Background] Failed to set track events:', error);
                            sendResponse({ error: 'Failed to set track events' });
                        });
                        return true;
                    }
                    break;
                case 'GET_EXPORT_PREVIEW':
                    this.getExportPreview(tabId).then((preview) => {
                        sendResponse({ preview });
                    }).catch(error => {
                        console.error('[Background] Failed to get export preview:', error);
                        sendResponse({ error: 'Failed to get export preview' });
                    });
                    return true;
            }
        });
    }
    setupTabHandlers() {
        chrome.tabs.onRemoved.addListener((tabId) => {
            if (this.tabWindowMap.has(tabId)) {
                const windowId = this.tabWindowMap.get(tabId);
                const windowState = this.windowData.get(windowId);
                if (windowState) {
                    windowState.tabIds.delete(tabId);
                    if (windowState.tabIds.size === 0 && windowState.recording && windowState.events.length > 0) {
                        console.log(`Last tab ${tabId} closed with recording enabled - auto-exporting window ${windowId}`);
                        this.exportEvents(tabId, true).catch(error => {
                            console.error('[Background] Failed to auto-export on tab close:', error);
                        });
                    }
                }
                this.tabWindowMap.delete(tabId);
                console.debug(`[Background] Cleaned up tab ${tabId} from window ${windowId}`);
            }
        });
    }
    setupWindowHandlers() {
        chrome.windows.onRemoved.addListener((windowId) => {
            if (this.windowData.has(windowId)) {
                const windowState = this.windowData.get(windowId);
                if (windowState.recording && windowState.events.length > 0) {
                    console.log(`Window ${windowId} closed with recording enabled - auto-exporting`);
                    const anyTabId = Array.from(windowState.tabIds)[0];
                    if (anyTabId) {
                        this.exportEvents(anyTabId, true).catch(error => {
                            console.error('[Background] Failed to auto-export on window close:', error);
                        });
                    }
                }
                for (const tabId of windowState.tabIds) {
                    this.tabWindowMap.delete(tabId);
                }
                this.windowData.delete(windowId);
                console.debug(`[Background] Cleaned up window ${windowId} and all associated tabs`);
            }
        });
    }
    async addEvent(tabId, event, url) {
        const windowId = await this.getWindowIdFromTab(tabId);
        this.addTabToWindow(windowId, tabId);
        const windowState = this.windowData.get(windowId);
        if (!windowState.recording) {
            return;
        }
        if (!event.start) {
            event.start = performance.now();
        }
        const normalizedUrl = this.normalizeUrlForGrouping(url);
        const taggedEvent = {
            ...event,
            _internalUrl: normalizedUrl
        };
        windowState.events.push(taggedEvent);
        this.handleEventCapAndUpdate(windowId, windowState);
    }
    async addEventBatch(tabId, events, url) {
        const windowId = await this.getWindowIdFromTab(tabId);
        this.addTabToWindow(windowId, tabId);
        const windowState = this.windowData.get(windowId);
        if (!windowState.recording) {
            return;
        }
        const normalizedUrl = this.normalizeUrlForGrouping(url);
        const now = performance.now();
        for (const event of events) {
            if (!event.start) {
                event.start = now;
            }
            const taggedEvent = {
                ...event,
                _internalUrl: normalizedUrl
            };
            windowState.events.push(taggedEvent);
        }
        this.handleEventCapAndUpdate(windowId, windowState);
    }
    handleEventCapAndUpdate(windowId, windowState) {
        if (windowState.events.length >= this.EVENT_CAP) {
            for (const windowTabId of windowState.tabIds) {
                this.sendToTab(windowTabId, {
                    type: 'HUD_MESSAGE',
                    level: 'warning',
                    message: `Event cap reached (${this.EVENT_CAP}). Oldest events will be dropped.`
                });
            }
            windowState.events = windowState.events.slice(-this.EVENT_CAP);
        }
        this.throttledHudUpdate(windowId, windowState);
    }
    throttledHudUpdate(windowId, windowState) {
        const now = Date.now();
        const lastUpdate = this.hudUpdateThrottle.get(windowId) || 0;
        if (now - lastUpdate >= this.hudUpdateInterval) {
            for (const windowTabId of windowState.tabIds) {
                this.sendToTab(windowTabId, {
                    type: 'HUD_UPDATE',
                    eventCount: windowState.events.length,
                    atCap: windowState.events.length >= this.EVENT_CAP
                });
            }
            this.hudUpdateThrottle.set(windowId, now);
        }
    }
    async toggleRecording(tabId) {
        const windowId = await this.getWindowIdFromTab(tabId);
        this.addTabToWindow(windowId, tabId);
        const windowState = this.windowData.get(windowId);
        windowState.recording = !windowState.recording;
        for (const windowTabId of windowState.tabIds) {
            this.sendToTab(windowTabId, {
                type: 'HUD_UPDATE',
                recording: windowState.recording,
                eventCount: windowState.events.length
            });
            if (windowState.recording) {
                this.sendToTab(windowTabId, {
                    type: 'HUD_MESSAGE',
                    level: 'info',
                    message: 'Recording started - watching input interactions'
                });
                this.sendToTab(windowTabId, {
                    type: 'SET_RECORDING_MODE',
                    recordingMode: windowState.recordingMode
                });
            }
            else {
                this.sendToTab(windowTabId, {
                    type: 'HUD_MESSAGE',
                    level: 'info',
                    message: 'Recording stopped'
                });
            }
            this.sendToTab(windowTabId, {
                type: 'SET_RECORDING_STATE',
                recording: windowState.recording
            });
        }
    }
    isRecording(tabId) {
        const windowId = this.tabWindowMap.get(tabId);
        return this.windowData.get(windowId)?.recording || false;
    }
    async setRecordingMode(tabId, mode) {
        const windowId = await this.getWindowIdFromTab(tabId);
        this.addTabToWindow(windowId, tabId);
        const windowState = this.windowData.get(windowId);
        windowState.recordingMode = mode;
        console.debug(`[Background] Recording mode set to ${mode} for window ${windowId}`);
        for (const windowTabId of windowState.tabIds) {
            this.sendToTab(windowTabId, {
                type: 'SET_RECORDING_MODE',
                recordingMode: mode
            });
        }
    }
    async setFilters(tabId, filters) {
        const windowId = await this.getWindowIdFromTab(tabId);
        this.addTabToWindow(windowId, tabId);
        const windowState = this.windowData.get(windowId);
        windowState.filters = filters;
        console.debug(`[Background] Filters updated for window ${windowId}:`, filters);
        for (const windowTabId of windowState.tabIds) {
            this.sendToTab(windowTabId, {
                type: 'SET_FILTERS',
                filters: filters
            });
        }
    }
    async setTrackEvents(tabId, trackEvents) {
        const windowId = await this.getWindowIdFromTab(tabId);
        this.addTabToWindow(windowId, tabId);
        const windowState = this.windowData.get(windowId);
        windowState.trackEvents = trackEvents;
        console.debug(`[Background] Track Events updated for window ${windowId}:`, trackEvents);
        for (const windowTabId of windowState.tabIds) {
            this.sendToTab(windowTabId, {
                type: 'SET_TRACK_EVENTS',
                trackEvents: trackEvents
            });
        }
    }
    async clearEvents(tabId) {
        const windowId = await this.getWindowIdFromTab(tabId);
        this.addTabToWindow(windowId, tabId);
        const windowState = this.windowData.get(windowId);
        windowState.events = [];
        for (const windowTabId of windowState.tabIds) {
            this.sendToTab(windowTabId, {
                type: 'HUD_UPDATE',
                eventCount: 0,
                atCap: false
            });
            this.sendToTab(windowTabId, {
                type: 'HUD_MESSAGE',
                level: 'info',
                message: 'Events cleared'
            });
        }
    }
    async initializeTab(tabId, url) {
        const windowId = await this.getWindowIdFromTab(tabId);
        this.addTabToWindow(windowId, tabId);
        console.debug(`[Background] Initialized tab ${tabId} in window ${windowId}`);
    }
    deduplicateEvents(events) {
        const actionMap = new Set();
        const deduplicatedEvents = [];
        for (const event of events) {
            const key = `${event.type}__${event.data}__${event.target.id}`;
            if (!actionMap.has(key)) {
                actionMap.add(key);
                deduplicatedEvents.push(event);
            }
        }
        return {
            deduplicated: deduplicatedEvents,
            originalCount: events.length,
            deduplicatedCount: deduplicatedEvents.length,
            duplicatesRemoved: events.length - deduplicatedEvents.length
        };
    }
    async exportEvents(tabId, isAutoExport = false) {
        const windowId = await this.getWindowIdFromTab(tabId);
        const windowState = this.windowData.get(windowId);
        if (!windowState || windowState.events.length === 0) {
            if (!isAutoExport) {
                this.sendToTab(tabId, {
                    type: 'HUD_MESSAGE',
                    level: 'warning',
                    message: 'No events to export'
                });
            }
            return;
        }
        const eventsByUrl = new Map();
        for (const event of windowState.events) {
            const url = event._internalUrl || 'unknown-url';
            if (!eventsByUrl.has(url)) {
                eventsByUrl.set(url, []);
            }
            eventsByUrl.get(url).push(event);
        }
        const now = new Date();
        const dateStr = now.toISOString().split('T')[0];
        const timeStr = now.toTimeString().split(' ')[0].replace(/:/g, '-');
        const sessionFolder = `evidence_session_${dateStr}_${timeStr}`;
        let totalExportedEvents = 0;
        let filesCreated = 0;
        for (const [normalizedUrl, urlEvents] of eventsByUrl) {
            const cleanEvents = urlEvents.map(event => {
                const { _internalUrl, ...cleanEvent } = event;
                return cleanEvent;
            });
            const deduplicationResult = this.deduplicateEvents(cleanEvents);
            const filename = this.createFilename(normalizedUrl, now);
            const fullPath = `${sessionFolder}/${filename}`;
            const exportData = {
                metadata: {
                    url: normalizedUrl,
                    exportedAt: now.toISOString(),
                    eventCount: deduplicationResult.deduplicatedCount,
                    recordingStarted: new Date(windowState.createdAt).toISOString(),
                    autoExported: isAutoExport,
                    windowId: windowId,
                    deduplication: {
                        originalCount: deduplicationResult.originalCount,
                        deduplicatedCount: deduplicationResult.deduplicatedCount,
                        duplicatesRemoved: deduplicationResult.duplicatesRemoved
                    }
                },
                events: deduplicationResult.deduplicated
            };
            const jsonString = JSON.stringify(exportData, null, 2);
            const dataUrl = 'data:application/json;charset=utf-8,' + encodeURIComponent(jsonString);
            chrome.downloads.download({
                url: dataUrl,
                filename: fullPath,
                saveAs: !isAutoExport && filesCreated === 0
            });
            totalExportedEvents += deduplicationResult.deduplicatedCount;
            filesCreated++;
        }
        if (!isAutoExport) {
            const summaryMessage = filesCreated === 1
                ? `Exported ${totalExportedEvents} events to 1 file in ${sessionFolder}/`
                : `Exported ${totalExportedEvents} events to ${filesCreated} files in ${sessionFolder}/`;
            for (const windowTabId of windowState.tabIds) {
                this.sendToTab(windowTabId, {
                    type: 'HUD_MESSAGE',
                    level: 'success',
                    message: summaryMessage
                });
            }
        }
        console.debug(`[Background] Exported ${totalExportedEvents} events across ${filesCreated} files to ${sessionFolder}/`);
    }
    async getExportPreview(tabId) {
        const windowId = await this.getWindowIdFromTab(tabId);
        const windowState = this.windowData.get(windowId);
        if (!windowState || windowState.events.length === 0) {
            return {};
        }
        const eventsByUrl = new Map();
        for (const event of windowState.events) {
            const url = event._internalUrl || 'unknown-url';
            if (!eventsByUrl.has(url)) {
                eventsByUrl.set(url, []);
            }
            eventsByUrl.get(url).push(event);
        }
        const now = new Date();
        const preview = {};
        for (const [normalizedUrl, urlEvents] of eventsByUrl) {
            const cleanEvents = urlEvents.map(event => {
                const { _internalUrl, ...cleanEvent } = event;
                return cleanEvent;
            });
            const deduplicationResult = this.deduplicateEvents(cleanEvents);
            const filename = this.createFilename(normalizedUrl, now);
            preview[normalizedUrl] = {
                eventCount: deduplicationResult.deduplicatedCount,
                filename: filename
            };
        }
        return preview;
    }
    sendToTab(tabId, message) {
        chrome.tabs.sendMessage(tabId, message).catch(() => {
        });
    }
}
const evidenceManager = new EvidenceManager();
console.log('Input Evidence Extension background service worker initialized');
export {};
