export class StackTrace {
    static capture() {
        try {
            const error = new Error();
            const stack = error.stack;
            if (!stack || typeof stack !== 'string') {
                throw new Error('Stack trace is empty or invalid');
            }
            return this.parseAndFormat(stack);
        }
        catch (captureError) {
            console.error('[StackTrace] Failed to capture stack trace:', captureError);
            return ['[STACK_TRACE_CAPTURE_FAILED]'];
        }
    }
    static parseAndFormat(stackString) {
        try {
            const lines = stackString.split('\n');
            const formattedFrames = [];
            for (const line of lines) {
                if (line.trim() === '' || line.trim() === 'Error') {
                    continue;
                }
                const parsedFrame = this.parseStackFrame(line.trim());
                if (parsedFrame && this.shouldIncludeFrame(parsedFrame)) {
                    const formattedFrame = this.formatFrame(parsedFrame);
                    if (formattedFrame) {
                        formattedFrames.push(formattedFrame);
                    }
                }
            }
            return formattedFrames.length > 0 ? formattedFrames : ['[NO_VALID_STACK_FRAMES]'];
        }
        catch (parseError) {
            console.error('[StackTrace] Failed to parse stack trace:', parseError);
            return ['[STACK_TRACE_PARSE_FAILED]'];
        }
    }
    static parseStackFrame(frame) {
        try {
            const cleanFrame = frame.replace(/^\s*at\s+/, '');
            let match = cleanFrame.match(/^(.+?)\s+\((.+?):(\d+):(\d+)\)$/);
            if (match) {
                const [, functionName, url, line, column] = match;
                return {
                    url: url.trim(),
                    line: parseInt(line, 10),
                    column: parseInt(column, 10),
                    functionName: functionName.trim()
                };
            }
            match = cleanFrame.match(/^(.+?):(\d+):(\d+)$/);
            if (match) {
                const [, url, line, column] = match;
                return {
                    url: url.trim(),
                    line: parseInt(line, 10),
                    column: parseInt(column, 10)
                };
            }
            match = cleanFrame.match(/^(.+?)\s+\(eval\s+at\s+.+?\((.+?):(\d+):(\d+)\)/);
            if (match) {
                const [, functionName, url, line, column] = match;
                return {
                    url: url.trim(),
                    line: parseInt(line, 10),
                    column: parseInt(column, 10),
                    functionName: `${functionName.trim()} [eval]`
                };
            }
            return null;
        }
        catch (error) {
            return null;
        }
    }
    static shouldIncludeFrame(frame) {
        const isOurExtension = frame.url.includes('chrome-extension://') &&
            (frame.url.includes('injected.js') ||
                frame.url.includes('content.js') ||
                frame.url.includes('background.js') ||
                frame.url.includes('main-world-hooks.js') ||
                frame.url.includes('shared-types.js'));
        if (isOurExtension) {
            return false;
        }
        const isBrowserInternal = frame.url.startsWith('about:config') ||
            frame.url.startsWith('about:chrome') ||
            frame.url.startsWith('about:debugging') ||
            frame.url.startsWith('about:preferences') ||
            frame.url.startsWith('about:memory') ||
            frame.url.startsWith('about:support') ||
            frame.url.startsWith('chrome://') ||
            frame.url.startsWith('edge://') ||
            frame.url.startsWith('firefox://');
        if (isBrowserInternal) {
            return false;
        }
        if (!frame.url || frame.url.trim() === '' || frame.url === 'null' || frame.url === 'undefined') {
            return false;
        }
        return true;
    }
    static formatFrame(frame) {
        try {
            const baseFormat = `${frame.url}:${frame.line}:${frame.column}`;
            if (frame.functionName && this.isMeaningfulFunctionName(frame.functionName)) {
                return `${baseFormat} [${frame.functionName}]`;
            }
            return baseFormat;
        }
        catch (error) {
            return null;
        }
    }
    static isMeaningfulFunctionName(functionName) {
        if (!functionName || functionName.trim() === '') {
            return false;
        }
        return true;
    }
    static captureWithContext(context) {
        const frames = this.capture();
        if (frames.length > 0 && !frames[0].includes('FAILED')) {
            console.debug(`[StackTrace] Captured ${frames.length} frames for context: ${context}`);
        }
        return frames;
    }
}
StackTrace.ANONYMOUS_PATTERNS = [
    '<anonymous>',
    'Object.<anonymous>',
    'anonymous'
];
