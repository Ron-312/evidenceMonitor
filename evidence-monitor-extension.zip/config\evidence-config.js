import { trackEventsManager } from '../state/track-events-manager';
export const EVIDENCE_CONFIG = {
    formElements: {
        elements: ['input', 'select', 'textarea'],
        propertyGetters: [
            'value',
            'nodeValue'
        ],
        eventHandlerSetters: [
            'onkeydown',
            'onkeypress',
            'onkeyup',
            'oninput',
            'onchange'
        ],
        eventListeners: [
            'keydown',
            'keypress',
            'keyup',
            'input',
            'change'
        ]
    },
    formSubmission: {
        elements: ['form'],
        methods: ['submit'],
        eventListeners: ['submit']
    },
    formDataCreation: {
        constructor: 'FormData'
    }
};
export function isFormElement(element) {
    return EVIDENCE_CONFIG.formElements.elements.some(tag => element.tagName.toLowerCase() === tag);
}
export function shouldHookPropertyGetter(element, propertyName) {
    return trackEventsManager.isInputValueAccessEnabled() &&
        isFormElement(element) &&
        EVIDENCE_CONFIG.formElements.propertyGetters.includes(propertyName);
}
export function shouldHookEventHandlerSetter(target, propertyName) {
    if (target instanceof Element && isFormElement(target)) {
        return trackEventsManager.isInputEventsEnabled() &&
            EVIDENCE_CONFIG.formElements.eventHandlerSetters.includes(propertyName);
    }
    return false;
}
export function shouldHookEventListener(target, eventType) {
    if (target instanceof Element && isFormElement(target)) {
        return trackEventsManager.isInputEventsEnabled() &&
            EVIDENCE_CONFIG.formElements.eventListeners.includes(eventType);
    }
    return false;
}
export function shouldHookFormSubmission(target, action) {
    if (target instanceof HTMLFormElement) {
        return trackEventsManager.isFormSubmitEnabled() &&
            EVIDENCE_CONFIG.formSubmission.methods.includes(action);
    }
    return false;
}
export function shouldHookFormDataCreation(constructorName) {
    return trackEventsManager.isFormDataCreationEnabled() &&
        constructorName === EVIDENCE_CONFIG.formDataCreation.constructor;
}
export function generateEvidenceType(target, action, hookType) {
    let targetName;
    if (target instanceof Element) {
        targetName = target.tagName.toLowerCase();
    }
    else {
        targetName = 'unknown';
    }
    switch (hookType) {
        case 'property':
            return `${targetName}.${action}/get`;
        case 'eventHandler':
            return `${targetName}.${action}/set`;
        case 'addEventListener':
            return `${targetName}.addEventListener(${action})`;
        default:
            return `${targetName}.${action}`;
    }
}
