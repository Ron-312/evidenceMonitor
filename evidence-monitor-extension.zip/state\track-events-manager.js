class TrackEventsManager {
    constructor() {
        this.trackEventsState = {
            inputValueAccess: true,
            inputEvents: true,
            formSubmit: true,
            formDataCreation: true
        };
    }
    setTrackEvents(trackEvents) {
        this.trackEventsState = { ...trackEvents };
        console.debug('[TrackEventsManager] Track events updated:', trackEvents);
    }
    getTrackEvents() {
        return { ...this.trackEventsState };
    }
    isInputValueAccessEnabled() {
        return this.trackEventsState.inputValueAccess;
    }
    isInputEventsEnabled() {
        return this.trackEventsState.inputEvents;
    }
    isFormSubmitEnabled() {
        return this.trackEventsState.formSubmit;
    }
    isFormDataCreationEnabled() {
        return this.trackEventsState.formDataCreation;
    }
    getStats() {
        const enabled = Object.values(this.trackEventsState).filter(Boolean).length;
        const total = Object.keys(this.trackEventsState).length;
        return {
            trackEventsState: this.getTrackEvents(),
            enabledCount: enabled,
            totalCategories: total
        };
    }
}
export const trackEventsManager = new TrackEventsManager();
