"use strict";
(() => {
  // src/injected/utils/element-registry.ts
  var ElementRegistry = class {
    constructor() {
      this.elementToId = /* @__PURE__ */ new Map();
      this.existingIds = /* @__PURE__ */ new Set();
      this.MAX_ELEMENTS = 5e3;
      this.cleanupCounter = 0;
      this.CLEANUP_INTERVAL = 100;
    }
    /**
     * Gets a stable ID for the given element. Creates new ID if element not seen before.
     * Returns consistent ID for same element across multiple calls.
     */
    getElementId(element) {
      if (!element || !(element instanceof Element)) {
        throw new Error("ElementRegistry.getElementId() requires a valid DOM Element");
      }
      if (this.elementToId.has(element)) {
        return this.elementToId.get(element);
      }
      if (++this.cleanupCounter % this.CLEANUP_INTERVAL === 0) {
        this.performCleanup();
      }
      const newId = this.generateUniqueElementId();
      this.elementToId.set(element, newId);
      this.existingIds.add(newId);
      return newId;
    }
    /**
     * Checks if element already has an assigned ID
     */
    hasElementId(element) {
      if (!element || !(element instanceof Element)) {
        return false;
      }
      return this.elementToId.has(element);
    }
    /**
     * Gets current registry statistics for debugging/monitoring
     */
    getStats() {
      return {
        totalElements: this.elementToId.size,
        memoryPressure: this.elementToId.size > this.MAX_ELEMENTS * 0.8
      };
    }
    /**
     * Clears all element registrations (for testing/cleanup)
     */
    clearRegistry() {
      this.elementToId.clear();
      this.existingIds.clear();
      this.cleanupCounter = 0;
    }
    /**
     * Generates unique element ID matching Explorer format
     * Uses collision detection to ensure uniqueness
     */
    generateUniqueElementId() {
      let id;
      let attempts = 0;
      const maxAttempts = 10;
      do {
        id = Math.random().toString(36).substr(2);
        attempts++;
        if (attempts >= maxAttempts) {
          id = Math.random().toString(36).substr(2) + Date.now().toString(36);
          break;
        }
      } while (this.existingIds.has(id));
      return id;
    }
    /**
     * Removes elements no longer in DOM and enforces size limits
     */
    performCleanup() {
      let removedCount = 0;
      for (const [element, id] of this.elementToId) {
        if (!document.contains(element)) {
          this.elementToId.delete(element);
          this.existingIds.delete(id);
          removedCount++;
        }
      }
      if (this.elementToId.size > this.MAX_ELEMENTS) {
        const elementsToRemove = this.elementToId.size - this.MAX_ELEMENTS;
        let removed = 0;
        for (const [element, id] of this.elementToId) {
          if (removed >= elementsToRemove) break;
          this.elementToId.delete(element);
          this.existingIds.delete(id);
          removed++;
        }
        console.warn(`[ElementRegistry] Removed ${removed} oldest elements to stay within ${this.MAX_ELEMENTS} limit`);
      }
      if (removedCount > 0) {
        console.debug(`[ElementRegistry] Cleaned up ${removedCount} detached elements`);
      }
    }
  };

  // src/injected/utils/stack-trace.ts
  var StackTrace = class {
    /**
     * Captures current call stack and formats for evidence
     * Returns array of formatted stack frames matching Explorer format
     */
    static capture() {
      try {
        const error = new Error();
        const stack = error.stack;
        if (!stack || typeof stack !== "string") {
          throw new Error("Stack trace is empty or invalid");
        }
        return this.parseAndFormat(stack);
      } catch (captureError) {
        console.error("[StackTrace] Failed to capture stack trace:", captureError);
        return ["[STACK_TRACE_CAPTURE_FAILED]"];
      }
    }
    /**
     * Parses raw stack trace string and formats to Explorer-compatible array
     */
    static parseAndFormat(stackString) {
      try {
        const lines = stackString.split("\n");
        const formattedFrames = [];
        for (const line of lines) {
          if (line.trim() === "" || line.trim() === "Error") {
            continue;
          }
          const parsedFrame = this.parseStackFrame(line.trim());
          if (parsedFrame && this.shouldIncludeFrame(parsedFrame)) {
            const formattedFrame = this.formatFrame(parsedFrame);
            if (formattedFrame) {
              formattedFrames.push(formattedFrame);
            }
          }
        }
        return formattedFrames.length > 0 ? formattedFrames : ["[NO_VALID_STACK_FRAMES]"];
      } catch (parseError) {
        console.error("[StackTrace] Failed to parse stack trace:", parseError);
        return ["[STACK_TRACE_PARSE_FAILED]"];
      }
    }
    /**
     * Parses individual stack frame line into components
     * Handles various browser stack trace formats
     */
    static parseStackFrame(frame) {
      try {
        const cleanFrame = frame.replace(/^\s*at\s+/, "");
        let match = cleanFrame.match(/^(.+?)\s+\((.+?):(\d+):(\d+)\)$/);
        if (match) {
          const [, functionName, url, line, column] = match;
          return {
            url: url.trim(),
            line: parseInt(line, 10),
            column: parseInt(column, 10),
            functionName: functionName.trim()
          };
        }
        match = cleanFrame.match(/^(.+?):(\d+):(\d+)$/);
        if (match) {
          const [, url, line, column] = match;
          return {
            url: url.trim(),
            line: parseInt(line, 10),
            column: parseInt(column, 10)
          };
        }
        match = cleanFrame.match(/^(.+?)\s+\(eval\s+at\s+.+?\((.+?):(\d+):(\d+)\)/);
        if (match) {
          const [, functionName, url, line, column] = match;
          return {
            url: url.trim(),
            line: parseInt(line, 10),
            column: parseInt(column, 10),
            functionName: `${functionName.trim()} [eval]`
          };
        }
        return null;
      } catch (error) {
        return null;
      }
    }
    /**
     * Determines if stack frame should be included in evidence
     * Filters out extension frames and invalid URLs
     */
    static shouldIncludeFrame(frame) {
      const isExtensionFrame = this.EXTENSION_PATTERNS.some(
        (pattern) => frame.url.includes(pattern)
      );
      if (isExtensionFrame) {
        return false;
      }
      const isValidUrl = frame.url.startsWith("http://") || frame.url.startsWith("https://") || frame.url.startsWith("file://") || frame.url.startsWith("/");
      return isValidUrl;
    }
    /**
     * Formats parsed frame to Explorer format: "URL:line:col [functionName]"
     */
    static formatFrame(frame) {
      try {
        const baseFormat = `${frame.url}:${frame.line}:${frame.column}`;
        if (frame.functionName && this.isMeaningfulFunctionName(frame.functionName)) {
          return `${baseFormat} [${frame.functionName}]`;
        }
        return baseFormat;
      } catch (error) {
        return null;
      }
    }
    /**
     * Checks if function name is meaningful (not anonymous)
     */
    static isMeaningfulFunctionName(functionName) {
      if (!functionName || functionName.trim() === "") {
        return false;
      }
      const isAnonymous = this.ANONYMOUS_PATTERNS.some(
        (pattern) => functionName.includes(pattern)
      );
      return !isAnonymous;
    }
    /**
     * Utility method for testing - captures stack with known depth
     */
    static captureWithContext(context) {
      const frames = this.capture();
      if (frames.length > 0 && !frames[0].includes("FAILED")) {
        console.debug(`[StackTrace] Captured ${frames.length} frames for context: ${context}`);
      }
      return frames;
    }
  };
  // Chrome extension URL patterns to filter out
  StackTrace.EXTENSION_PATTERNS = [
    "chrome-extension://",
    "moz-extension://",
    "webkit-masked-url://"
  ];
  // Anonymous function patterns to ignore
  StackTrace.ANONYMOUS_PATTERNS = [
    "<anonymous>",
    "Object.<anonymous>",
    "anonymous"
  ];

  // src/injected/state/track-events-manager.ts
  var TrackEventsManager = class {
    constructor() {
      this.trackEventsState = {
        inputValueAccess: true,
        inputEvents: true,
        formSubmit: true,
        formDataCreation: true
      };
    }
    /**
     * Updates the track events configuration from HUD
     */
    setTrackEvents(trackEvents) {
      this.trackEventsState = { ...trackEvents };
      console.debug("[TrackEventsManager] Track events updated:", trackEvents);
    }
    /**
     * Returns current track events state
     */
    getTrackEvents() {
      return { ...this.trackEventsState };
    }
    /**
     * Checks if Input Value Access tracking is enabled
     * Controls property getter hooks (input.value, textarea.value, etc.)
     */
    isInputValueAccessEnabled() {
      return this.trackEventsState.inputValueAccess;
    }
    /**
     * Checks if Input Events tracking is enabled
     * Controls addEventListener hooks for keydown, input, change, etc.
     */
    isInputEventsEnabled() {
      return this.trackEventsState.inputEvents;
    }
    /**
     * Checks if Form Submit tracking is enabled
     * Controls form.submit() method hooks and submit event listeners
     */
    isFormSubmitEnabled() {
      return this.trackEventsState.formSubmit;
    }
    /**
     * Checks if FormData Creation tracking is enabled
     * Controls FormData constructor hooks (new FormData())
     */
    isFormDataCreationEnabled() {
      return this.trackEventsState.formDataCreation;
    }
    /**
     * Gets current statistics for debugging
     */
    getStats() {
      const enabled = Object.values(this.trackEventsState).filter(Boolean).length;
      const total = Object.keys(this.trackEventsState).length;
      return {
        trackEventsState: this.getTrackEvents(),
        enabledCount: enabled,
        totalCategories: total
      };
    }
  };
  var trackEventsManager = new TrackEventsManager();

  // src/injected/config/evidence-config.ts
  var EVIDENCE_CONFIG = {
    // HTMLInputElement, HTMLSelectElement, HTMLTextAreaElement hooks
    formElements: {
      elements: ["input", "select", "textarea"],
      // Property getters to hook (when scripts READ values)
      propertyGetters: [
        "value",
        // Most common - input.value, select.value, textarea.value
        "nodeValue"
        // Alternative access pattern - element.nodeValue
      ],
      // Event handler property setters (when scripts SET event handlers)
      eventHandlerSetters: [
        "onkeydown",
        // element.onkeydown = handler
        "onkeypress",
        // element.onkeypress = handler
        "onkeyup",
        // element.onkeyup = handler
        "oninput",
        // element.oninput = handler
        "onchange"
        // element.onchange = handler
      ],
      // addEventListener calls to monitor
      eventListeners: [
        "keydown",
        // element.addEventListener('keydown', handler)
        "keypress",
        // element.addEventListener('keypress', handler)
        "keyup",
        // element.addEventListener('keyup', handler)
        "input",
        // element.addEventListener('input', handler)
        "change"
        // element.addEventListener('change', handler)
      ]
    },
    // Form submission surveillance (matches Explorer pattern)
    formSubmission: {
      elements: ["form"],
      // HTMLFormElement
      methods: ["submit"],
      // form.submit() method
      eventListeners: ["submit"]
      // form.addEventListener('submit', handler)
    },
    // FormData creation surveillance (matches Explorer pattern)
    formDataCreation: {
      constructor: "FormData"
      // new FormData() constructor
    }
  };
  function isFormElement(element) {
    return EVIDENCE_CONFIG.formElements.elements.some(
      (tag) => element.tagName.toLowerCase() === tag
    );
  }
  function shouldHookPropertyGetter(element, propertyName) {
    return trackEventsManager.isInputValueAccessEnabled() && isFormElement(element) && EVIDENCE_CONFIG.formElements.propertyGetters.includes(propertyName);
  }
  function shouldHookEventHandlerSetter(target, propertyName) {
    if (target instanceof Element && isFormElement(target)) {
      return trackEventsManager.isInputEventsEnabled() && EVIDENCE_CONFIG.formElements.eventHandlerSetters.includes(propertyName);
    }
    return false;
  }
  function shouldHookEventListener(target, eventType) {
    if (target instanceof Element && isFormElement(target)) {
      return trackEventsManager.isInputEventsEnabled() && EVIDENCE_CONFIG.formElements.eventListeners.includes(eventType);
    }
    return false;
  }
  function shouldHookFormSubmission(target, action) {
    if (target instanceof HTMLFormElement) {
      return trackEventsManager.isFormSubmitEnabled() && EVIDENCE_CONFIG.formSubmission.methods.includes(action);
    }
    return false;
  }
  function shouldHookFormDataCreation(constructorName) {
    return trackEventsManager.isFormDataCreationEnabled() && constructorName === EVIDENCE_CONFIG.formDataCreation.constructor;
  }
  function generateEvidenceType(target, action, hookType) {
    let targetName;
    if (target instanceof Element) {
      targetName = target.tagName.toLowerCase();
    } else {
      targetName = "unknown";
    }
    switch (hookType) {
      case "property":
        return `${targetName}.${action}/get`;
      case "eventHandler":
        return `${targetName}.${action}/set`;
      case "addEventListener":
        return `${targetName}.addEventListener(${action})`;
      default:
        return `${targetName}.${action}`;
    }
  }

  // src/injected/state/recording-modes-manager.ts
  var RecordingModeHandler = class {
    constructor() {
      this.currentMode = "console";
      this.isRecording = false;
    }
    /**
     * Sets the current recording mode
     */
    setMode(mode) {
      this.currentMode = mode;
      console.debug(`[RecordingMode] Mode set to: ${mode}`);
    }
    /**
     * Gets the current recording mode
     */
    getMode() {
      return this.currentMode;
    }
    /**
     * Sets the recording state
     */
    setRecording(recording) {
      this.isRecording = recording;
      console.debug(`[RecordingMode] Recording state set to: ${recording}`);
    }
    /**
     * Gets the current recording state
     */
    isCurrentlyRecording() {
      return this.isRecording;
    }
    /**
     * Logs evidence to console with detailed information
     */
    logEvidence(target, action, hookType, stackTrace) {
      if (!this.isRecording || this.currentMode !== "console") return;
      const targetInfo = this.getTargetInfo(target);
      const evidenceType = this.generateEvidenceType(target, action, hookType);
      console.group(`\u{1F50D} Surveillance Detected: ${evidenceType}`);
      console.log("Target:", targetInfo);
      console.log("Action:", action);
      console.log("Hook Type:", hookType);
      console.log("Element:", target);
      if (stackTrace && stackTrace.length > 0) {
        console.log("Stack Trace:");
        stackTrace.forEach((frame, index) => {
          console.log(`  ${index + 1}. ${frame}`);
        });
      }
      console.groupEnd();
    }
    /**
     * Gets human-readable target information
     */
    getTargetInfo(target) {
      const tagName = target.tagName.toLowerCase();
      const id = target.id ? `#${target.id}` : "";
      const className = target.className ? `.${target.className.replace(/\s+/g, ".")}` : "";
      const name = target.getAttribute("name") ? `[name="${target.getAttribute("name")}"]` : "";
      return `${tagName}${id}${className}${name}`;
    }
    /**
     * Generates evidence type string matching the evidence-config pattern
     */
    generateEvidenceType(target, action, hookType) {
      const targetName = target.tagName.toLowerCase();
      switch (hookType) {
        case "property":
          return `${targetName}.${action}/get`;
        case "eventHandler":
          return `${targetName}.${action}/set`;
        case "addEventListener":
          return `${targetName}.addEventListener(${action})`;
        default:
          return `${targetName}.${action}`;
      }
    }
  };
  var recordingModeHandler = new RecordingModeHandler();

  // src/injected/state/filter-manager.ts
  var FilterManager = class {
    constructor() {
      this.filters = {
        elementSelector: "",
        attributeFilters: "",
        stackKeywordFilter: ""
      };
    }
    /**
     * Updates the current filter configuration
     */
    setFilters(filters) {
      this.filters = filters;
      console.debug("[FilterManager] Filters updated:", filters);
    }
    /**
     * Gets the current filter configuration
     */
    getFilters() {
      return { ...this.filters };
    }
    /**
     * Determines if an element should be monitored based on current filters
     * Returns true if ANY filter matches (OR logic) or if no filters are set
     */
    shouldMonitorElement(element) {
      try {
        if (this.hasNoFilters()) {
          return true;
        }
        if (this.filters.elementSelector.trim() && this.matchesElementSelector(element)) {
          return true;
        }
        if (this.filters.attributeFilters.trim() && this.matchesAttributeFilters(element)) {
          return true;
        }
        return false;
      } catch (error) {
        console.error("[FilterManager] Error in shouldMonitorElement:", error);
        return true;
      }
    }
    /**
     * Determines if a stack trace should trigger monitoring based on keyword filter
     * Returns true if keyword matches or if no stack filter is set
     */
    shouldMonitorStackTrace(stackTrace) {
      try {
        if (!this.filters.stackKeywordFilter.trim()) {
          return true;
        }
        const keyword = this.filters.stackKeywordFilter.toLowerCase();
        return stackTrace.some(
          (frame) => frame.toLowerCase().includes(keyword)
        );
      } catch (error) {
        console.error("[FilterManager] Error in shouldMonitorStackTrace:", error);
        return true;
      }
    }
    /**
     * Combined filter check for element and stack trace
     * Returns true if BOTH element and stack filters pass (AND logic between filter types)
     */
    shouldMonitor(element, stackTrace) {
      return this.shouldMonitorElement(element) && this.shouldMonitorStackTrace(stackTrace);
    }
    /**
     * Checks if no filters are currently set
     */
    hasNoFilters() {
      return !this.filters.elementSelector.trim() && !this.filters.attributeFilters.trim() && !this.filters.stackKeywordFilter.trim();
    }
    /**
     * Checks if element matches the CSS selector filter
     */
    matchesElementSelector(element) {
      try {
        const selectors = this.filters.elementSelector.split(",").map((s) => s.trim());
        return selectors.some((selector) => {
          if (!selector) return false;
          try {
            return element.matches(selector);
          } catch (selectorError) {
            console.warn(`[FilterManager] Invalid CSS selector: ${selector}`, selectorError);
            return false;
          }
        });
      } catch (error) {
        console.error("[FilterManager] Error in matchesElementSelector:", error);
        return false;
      }
    }
    /**
     * Checks if element matches the attribute filters
     */
    matchesAttributeFilters(element) {
      try {
        const attributeFilters = this.parseAttributeFilters();
        return attributeFilters.some((filter) => {
          const elementValue = element.getAttribute(filter.name);
          return elementValue === filter.value;
        });
      } catch (error) {
        console.error("[FilterManager] Error in matchesAttributeFilters:", error);
        return false;
      }
    }
    /**
     * Parses attribute filter string into structured format
     * Example: "name=password, type=email" -> [{name: "name", value: "password"}, {name: "type", value: "email"}]
     */
    parseAttributeFilters() {
      try {
        const filters = [];
        const pairs = this.filters.attributeFilters.split(",");
        for (const pair of pairs) {
          const trimmed = pair.trim();
          if (!trimmed) continue;
          const [name, value] = trimmed.split("=");
          if (name && value) {
            filters.push({
              name: name.trim(),
              value: value.trim()
            });
          }
        }
        return filters;
      } catch (error) {
        console.error("[FilterManager] Error parsing attribute filters:", error);
        return [];
      }
    }
    /**
     * Returns filter statistics for debugging
     */
    getStats() {
      return {
        hasElementSelector: !!this.filters.elementSelector.trim(),
        hasAttributeFilters: !!this.filters.attributeFilters.trim(),
        hasStackKeywordFilter: !!this.filters.stackKeywordFilter.trim(),
        attributeFilterCount: this.parseAttributeFilters().length,
        isActive: !this.hasNoFilters()
      };
    }
  };
  var filterManager = new FilterManager();

  // src/injected/evidence-collector.ts
  var EvidenceCollector = class {
    constructor(elementRegistry) {
      this.isContentScriptReady = false;
      this.pendingEvidence = [];
      this.recentEvents = /* @__PURE__ */ new Map();
      this.deduplicationWindow = 50;
      // 50ms
      this.maxQueueSize = 1e3;
      this.handshakeTimeout = 5e3;
      // 5 seconds
      this.handshakeTimer = null;
      this.elementRegistry = elementRegistry;
      this.setupHandshakeListener();
      this.startHandshakeTimeout();
    }
    /**
     * Creates and sends evidence for surveillance action
     * Handles deduplication and queuing until content script ready
     * Returns decision object for debugger breakpoint logic
     */
    createAndSendEvidence(element, action, hookType) {
      const evidence = this.createEvidence(element, action, hookType);
      const shouldProceed = filterManager.shouldMonitor(element, evidence.stackTrace);
      if (shouldProceed) {
        if (this.isDuplicate(evidence)) {
          return { shouldProceed: false, evidence };
        }
        this.recordForDeduplication(evidence);
        recordingModeHandler.logEvidence(element, action, hookType, evidence.stackTrace);
        this.sendEvidence(evidence);
      }
      return { shouldProceed, evidence };
    }
    /**
     * Creates evidence object from surveillance action
     */
    createEvidence(element, action, hookType) {
      const elementId = this.elementRegistry.getElementId(element);
      const stackTrace = StackTrace.capture();
      const evidenceType = generateEvidenceType(element, action, hookType);
      return {
        actionId: this.generateActionId(),
        type: evidenceType,
        start: performance.now(),
        duration: 0,
        // Always 0 for surveillance detection
        data: this.getElementData(element),
        target: { id: elementId },
        stackTrace
      };
    }
    /**
     * Generates unique action ID matching Explorer format
     */
    generateActionId() {
      return Math.random().toString(36).substr(2);
    }
    /**
     * Gets element data for evidence - ID, name, then outerHTML
     */
    getElementData(element) {
      try {
        if (element.id) {
          return element.id;
        }
        const nameAttr = element.getAttribute("name");
        if (nameAttr) {
          return nameAttr;
        }
        if (element.outerHTML) {
          return element.outerHTML.substring(0, 300);
        }
        return "[NO_ELEMENT_DATA]";
      } catch (error) {
        return "[ELEMENT_DATA_ERROR]";
      }
    }
    /**
     * Checks if evidence is duplicate within deduplication window
     */
    isDuplicate(evidence) {
      const key = this.generateDeduplicationKey(evidence);
      const now = performance.now();
      const lastTime = this.recentEvents.get(key);
      if (lastTime && now - lastTime < this.deduplicationWindow) {
        return true;
      }
      return false;
    }
    /**
     * Records evidence in deduplication map and cleans old entries
     */
    recordForDeduplication(evidence) {
      const key = this.generateDeduplicationKey(evidence);
      const now = performance.now();
      this.recentEvents.set(key, now);
      if (this.recentEvents.size > 1e3) {
        this.cleanupDeduplicationMap(now);
      }
    }
    /**
     * Generates deduplication key including full stack trace
     */
    generateDeduplicationKey(evidence) {
      return `${evidence.type}:${evidence.target.id}:${evidence.stackTrace.join("|")}`;
    }
    /**
     * Removes old entries from deduplication map
     */
    cleanupDeduplicationMap(currentTime) {
      const cleanupThreshold = currentTime - this.deduplicationWindow * 10;
      for (const [key, timestamp] of this.recentEvents.entries()) {
        if (timestamp < cleanupThreshold) {
          this.recentEvents.delete(key);
        }
      }
    }
    /**
     * Sends evidence immediately or queues if content script not ready
     */
    sendEvidence(evidence) {
      if (this.isContentScriptReady) {
        this.transmitEvidence(evidence);
      } else {
        this.queueEvidence(evidence);
      }
    }
    /**
     * Queues evidence with overflow protection
     */
    queueEvidence(evidence) {
      if (this.pendingEvidence.length >= this.maxQueueSize) {
        this.pendingEvidence.shift();
        console.warn(`[EvidenceCollector] Queue full, dropped oldest evidence. Queue size: ${this.maxQueueSize}`);
      }
      this.pendingEvidence.push(evidence);
      console.debug(`[EvidenceCollector] Queued evidence. Queue size: ${this.pendingEvidence.length}`);
    }
    /**
     * Transmits evidence to content script via window.postMessage
     */
    transmitEvidence(evidence) {
      try {
        window.postMessage({
          type: "EVIDENCE_EVENT",
          event: evidence
        }, "*");
      } catch (error) {
        console.error("[EvidenceCollector] Failed to transmit evidence:", error);
        this.queueEvidence(evidence);
      }
    }
    /**
     * Sets up listener for content script ready handshake
     */
    setupHandshakeListener() {
      window.addEventListener("message", (event) => {
        if (event.source !== window) return;
        if (event.data.type === "CONTENT_SCRIPT_READY") {
          this.onContentScriptReady();
        }
      });
    }
    /**
     * Handles content script ready signal
     */
    onContentScriptReady() {
      console.debug("[EvidenceCollector] Content script ready, flushing pending evidence");
      this.isContentScriptReady = true;
      if (this.handshakeTimer) {
        clearTimeout(this.handshakeTimer);
        this.handshakeTimer = null;
      }
      this.flushPendingEvidence();
    }
    /**
     * Sends all queued evidence to content script
     */
    flushPendingEvidence() {
      console.debug(`[EvidenceCollector] Flushing ${this.pendingEvidence.length} pending evidence events`);
      for (const evidence of this.pendingEvidence) {
        this.transmitEvidence(evidence);
      }
      this.pendingEvidence = [];
    }
    /**
     * Starts timeout for handshake - assumes ready if timeout expires
     */
    startHandshakeTimeout() {
      this.handshakeTimer = window.setTimeout(() => {
        if (!this.isContentScriptReady) {
          console.warn("[EvidenceCollector] Handshake timeout - assuming content script ready");
          this.onContentScriptReady();
        }
      }, this.handshakeTimeout);
    }
    /**
     * Gets current collector statistics for debugging
     */
    getStats() {
      return {
        ready: this.isContentScriptReady,
        queueSize: this.pendingEvidence.length,
        deduplicationEntries: this.recentEvents.size,
        memoryPressure: this.pendingEvidence.length > this.maxQueueSize * 0.8
      };
    }
    /**
     * Clears all pending evidence and resets state (for testing)
     */
    clearState() {
      this.pendingEvidence = [];
      this.recentEvents.clear();
      this.isContentScriptReady = false;
      if (this.handshakeTimer) {
        clearTimeout(this.handshakeTimer);
        this.handshakeTimer = null;
      }
    }
  };

  // src/injected/hooks/addEventListener-hook.ts
  var AddEventListenerHook = class {
    constructor(evidenceCollector) {
      this.name = "addEventListener";
      this.isHookInstalled = false;
      this.evidenceCollector = evidenceCollector;
      this.originalAddEventListener = EventTarget.prototype.addEventListener;
    }
    /**
     * Installs the addEventListener surveillance detection hook
     */
    install() {
      if (this.isHookInstalled) {
        console.warn(`[${this.name}] Hook already installed, skipping`);
        return;
      }
      try {
        const self = this;
        EventTarget.prototype.addEventListener = function(type, listener, options) {
          const { shouldProceed } = self.monitorAddEventListenerCall(this, type, listener, options);
          if (shouldProceed && recordingModeHandler.isCurrentlyRecording() && recordingModeHandler.getMode() === "breakpoint") {
            console.log(`\u{1F6D1} Breakpoint: addEventListener('${type}') on`, this);
            debugger;
          }
          return self.originalAddEventListener.call(this, type, listener, options);
        };
        this.isHookInstalled = true;
        console.debug(`[${this.name}] Surveillance detection hook installed successfully`);
      } catch (error) {
        console.error(`[${this.name}] Failed to install hook:`, error, {
          context: "EventTarget.prototype.addEventListener replacement"
        });
        throw error;
      }
    }
    /**
     * Removes the hook and restores original addEventListener functionality
     */
    uninstall() {
      if (!this.isHookInstalled) {
        console.debug(`[${this.name}] Hook not installed, nothing to uninstall`);
        return;
      }
      try {
        EventTarget.prototype.addEventListener = this.originalAddEventListener;
        this.isHookInstalled = false;
        console.debug(`[${this.name}] Hook uninstalled successfully`);
      } catch (error) {
        console.error(`[${this.name}] Failed to uninstall hook:`, error, {
          context: "EventTarget.prototype.addEventListener restoration"
        });
        this.isHookInstalled = false;
      }
    }
    /**
     * Returns whether the hook is currently installed
     */
    isInstalled() {
      return this.isHookInstalled;
    }
    /**
     * Monitors addEventListener call and creates evidence if surveillance detected
     */
    monitorAddEventListenerCall(target, eventType, listener, options) {
      try {
        if (target instanceof Element) {
          if (!this.shouldMonitorTarget(target, eventType)) {
            return { shouldProceed: false };
          }
          const result = this.evidenceCollector.createAndSendEvidence(
            target,
            eventType,
            "addEventListener"
          );
          return result;
        }
        console.debug(`[${this.name}] Non-Element EventTarget ignored:`, {
          target: target.constructor.name,
          eventType,
          targetToString: target.toString()
        });
        return { shouldProceed: false };
      } catch (error) {
        console.error(`[${this.name}] Error during surveillance monitoring:`, error, {
          context: {
            targetType: target.constructor.name,
            eventType,
            hasListener: !!listener
          }
        });
        return { shouldProceed: false };
      }
    }
    /**
     * Determines if this addEventListener call should be monitored for surveillance
     */
    shouldMonitorTarget(target, eventType) {
      try {
        if (target instanceof Element) {
          return shouldHookEventListener(target, eventType);
        }
        return false;
      } catch (error) {
        console.error(`[${this.name}] Error in shouldMonitorTarget:`, error, {
          context: { targetType: target.constructor.name, eventType }
        });
        return false;
      }
    }
  };

  // src/injected/hooks/property-getter-hooks.ts
  var PropertyGetterHooks = class {
    constructor(evidenceCollector) {
      this.name = "propertyGetters";
      this.originalDescriptors = [];
      this.isHookInstalled = false;
      this.evidenceCollector = evidenceCollector;
    }
    /**
     * Installs all property getter surveillance detection hooks
     */
    install() {
      if (this.isHookInstalled) {
        console.warn(`[${this.name}] Hook already installed, skipping`);
        return;
      }
      try {
        console.debug(`[${this.name}] Installing property getter surveillance hooks...`);
        this.installFormElementPropertyHooks();
        this.isHookInstalled = true;
        console.debug(`[${this.name}] Property getter surveillance hooks installed successfully`);
      } catch (error) {
        console.error(`[${this.name}] Failed to install hooks:`, error, {
          context: "Property descriptor replacement"
        });
        throw error;
      }
    }
    /**
     * Removes all hooks and restores original property descriptors
     */
    uninstall() {
      if (!this.isHookInstalled) {
        console.debug(`[${this.name}] Hook not installed, nothing to uninstall`);
        return;
      }
      try {
        console.debug(`[${this.name}] Uninstalling property getter hooks...`);
        for (const original of this.originalDescriptors) {
          Object.defineProperty(original.target, original.propertyName, original.descriptor);
        }
        this.originalDescriptors = [];
        this.isHookInstalled = false;
        console.debug(`[${this.name}] Property getter hooks uninstalled successfully`);
      } catch (error) {
        console.error(`[${this.name}] Failed to uninstall hooks:`, error, {
          context: "Property descriptor restoration"
        });
        this.isHookInstalled = false;
      }
    }
    /**
     * Returns whether the hooks are currently installed
     */
    isInstalled() {
      return this.isHookInstalled;
    }
    /**
     * Maps element name from config to its corresponding prototype
     */
    getElementPrototype(elementName) {
      const prototypeMap = {
        "input": HTMLInputElement.prototype,
        "select": HTMLSelectElement.prototype,
        "textarea": HTMLTextAreaElement.prototype
      };
      return prototypeMap[elementName];
    }
    /**
     * Install hooks for form element property getters (config-driven)
     */
    installFormElementPropertyHooks() {
      const formElements = EVIDENCE_CONFIG.formElements.elements;
      const propertyGetters = EVIDENCE_CONFIG.formElements.propertyGetters;
      formElements.forEach((elementName) => {
        const prototype = this.getElementPrototype(elementName);
        if (!prototype) {
          console.warn(`[${this.name}] No prototype found for element: ${elementName}`);
          return;
        }
        propertyGetters.forEach((propertyName) => {
          this.installPropertyHook(
            prototype,
            propertyName,
            `${elementName}.${propertyName} getter`
          );
        });
      });
      console.debug(`[${this.name}] Form element property getters hooked`);
    }
    /**
     * Finds a property descriptor by walking up the prototype chain (like Explorer's hookMembers)
     */
    findPropertyDescriptor(target, propertyName) {
      let current = target;
      while (current) {
        const descriptor = Object.getOwnPropertyDescriptor(current, propertyName);
        if (descriptor) {
          return descriptor;
        }
        current = Object.getPrototypeOf(current);
      }
      return null;
    }
    /**
     * Installs a surveillance hook for a specific property
     */
    installPropertyHook(target, propertyName, context) {
      try {
        const originalDescriptor = this.findPropertyDescriptor(target, propertyName);
        if (!originalDescriptor || !originalDescriptor.get) {
          throw new Error(`No getter found for ${context}`);
        }
        this.originalDescriptors.push({
          descriptor: originalDescriptor,
          target,
          propertyName
        });
        const self = this;
        const originalGetter = originalDescriptor.get;
        Object.defineProperty(target, propertyName, {
          get: function() {
            const { shouldProceed } = self.monitorPropertyAccess(this, propertyName);
            if (shouldProceed && recordingModeHandler.isCurrentlyRecording() && recordingModeHandler.getMode() === "breakpoint") {
              console.debug(`\u{1F6D1} Breakpoint: Property access ${propertyName} on`, this);
              debugger;
            }
            return originalGetter.call(this);
          },
          set: originalDescriptor.set,
          // Preserve original setter if exists
          configurable: true,
          enumerable: originalDescriptor.enumerable
        });
        console.debug(`[${this.name}] Installed hook for ${context}`);
      } catch (error) {
        console.error(`[${this.name}] Failed to install ${context}:`, error);
        throw error;
      }
    }
    /**
     * Monitors property access and creates evidence if surveillance detected
     */
    monitorPropertyAccess(target, propertyName) {
      try {
        if (!this.shouldMonitorPropertyAccess(target, propertyName)) {
          return { shouldProceed: false };
        }
        if (target instanceof Element) {
          const result = this.evidenceCollector.createAndSendEvidence(
            target,
            propertyName,
            "property"
          );
          return result;
        }
        return { shouldProceed: false };
      } catch (error) {
        console.error(`[${this.name}] Error during property access monitoring:`, error, {
          context: {
            targetType: target.constructor.name,
            propertyName,
            hasTarget: !!target
          }
        });
        return { shouldProceed: false };
      }
    }
    /**
     * Determines if this property access should be monitored for surveillance
     */
    shouldMonitorPropertyAccess(target, propertyName) {
      try {
        if (target instanceof Element) {
          return shouldHookPropertyGetter(target, propertyName);
        }
        return false;
      } catch (error) {
        console.error(`[${this.name}] Error in shouldMonitorPropertyAccess:`, error, {
          context: { targetType: target.constructor.name, propertyName }
        });
        return false;
      }
    }
  };

  // src/injected/hooks/event-handler-hooks.ts
  var EventHandlerHooks = class {
    constructor(evidenceCollector) {
      this.name = "eventHandlers";
      this.originalDescriptors = [];
      this.isHookInstalled = false;
      this.evidenceCollector = evidenceCollector;
    }
    /**
     * Installs all event handler setter surveillance detection hooks
     */
    install() {
      if (this.isHookInstalled) {
        console.warn(`[${this.name}] Hook already installed, skipping`);
        return;
      }
      try {
        console.debug(`[${this.name}] Installing event handler setter surveillance hooks...`);
        this.installFormElementHooks();
        this.isHookInstalled = true;
        console.debug(`[${this.name}] Event handler setter surveillance hooks installed successfully`);
      } catch (error) {
        console.error(`[${this.name}] Failed to install event handler hooks:`, error);
        throw error;
      }
    }
    /**
     * Uninstalls all event handler hooks and restores original descriptors
     */
    uninstall() {
      if (!this.isHookInstalled) {
        return;
      }
      try {
        console.debug(`[${this.name}] Uninstalling event handler surveillance hooks...`);
        this.originalDescriptors.forEach(({ target, propertyName, descriptor }) => {
          try {
            Object.defineProperty(target, propertyName, descriptor);
          } catch (error) {
            console.warn(`[${this.name}] Failed to restore ${propertyName}:`, error);
          }
        });
        this.originalDescriptors = [];
        this.isHookInstalled = false;
        console.debug(`[${this.name}] Event handler surveillance hooks uninstalled successfully`);
      } catch (error) {
        console.error(`[${this.name}] Error during hook uninstallation:`, error);
      }
    }
    /**
     * Returns hook installation status
     */
    isInstalled() {
      return this.isHookInstalled;
    }
    /**
     * Maps element name from config to its corresponding prototype
     */
    getElementPrototype(elementName) {
      const prototypeMap = {
        "input": HTMLInputElement.prototype,
        "select": HTMLSelectElement.prototype,
        "textarea": HTMLTextAreaElement.prototype
      };
      return prototypeMap[elementName];
    }
    /**
     * Install hooks for form element event handlers (config-driven)
     */
    installFormElementHooks() {
      const formElements = EVIDENCE_CONFIG.formElements.elements;
      const formEventHandlers = EVIDENCE_CONFIG.formElements.eventHandlerSetters;
      formElements.forEach((elementName) => {
        const prototype = this.getElementPrototype(elementName);
        if (!prototype) {
          console.warn(`[${this.name}] No prototype found for element: ${elementName}`);
          return;
        }
        formEventHandlers.forEach((handlerName) => {
          this.installEventHandlerSetter(prototype, handlerName, elementName);
        });
      });
    }
    /**
     * Installs a surveillance hook for a specific event handler property setter
     */
    installEventHandlerSetter(target, propertyName, targetType) {
      try {
        const originalDescriptor = Object.getOwnPropertyDescriptor(target, propertyName) || this.findDescriptorInPrototypeChain(target, propertyName);
        if (!originalDescriptor) {
          console.warn(`[${this.name}] No descriptor found for ${targetType}.${propertyName}, creating fallback`);
          this.createFallbackDescriptor(target, propertyName, targetType);
          return;
        }
        this.originalDescriptors.push({
          target,
          propertyName,
          descriptor: originalDescriptor
        });
        const self = this;
        const originalSetter = originalDescriptor.set;
        const originalGetter = originalDescriptor.get;
        const hookedSetter = function(handler) {
          const { shouldProceed } = this instanceof Element ? self.monitorEventHandlerAssignment(this, propertyName, handler) : { shouldProceed: false };
          if (shouldProceed && recordingModeHandler.isCurrentlyRecording() && recordingModeHandler.getMode() === "breakpoint") {
            console.log(`\u{1F6D1} Breakpoint: Event handler setter ${propertyName} on`, this);
            debugger;
          }
          if (originalSetter) {
            return originalSetter.call(this, handler);
          } else {
            this[`_${propertyName}`] = handler;
            return handler;
          }
        };
        const hookedGetter = originalGetter || function() {
          return this[`_${propertyName}`];
        };
        Object.defineProperty(target, propertyName, {
          get: hookedGetter,
          set: hookedSetter,
          configurable: originalDescriptor.configurable !== false,
          enumerable: originalDescriptor.enumerable !== false
        });
        console.debug(`[${this.name}] Hook installed for ${targetType}.${propertyName}`);
      } catch (error) {
        console.error(`[${this.name}] Failed to install hook for ${targetType}.${propertyName}:`, error);
      }
    }
    /**
     * Creates a fallback descriptor for event handler properties that don't exist
     */
    createFallbackDescriptor(target, propertyName, targetType) {
      try {
        const self = this;
        this.originalDescriptors.push({
          target,
          propertyName,
          descriptor: null
          // Mark as created by us
        });
        const hookedSetter = function(handler) {
          const { shouldProceed } = this instanceof Element ? self.monitorEventHandlerAssignment(this, propertyName, handler) : { shouldProceed: false };
          if (shouldProceed && recordingModeHandler.isCurrentlyRecording() && recordingModeHandler.getMode() === "breakpoint") {
            console.log(`\u{1F6D1} Breakpoint: Event handler setter ${propertyName} (fallback) on`, this);
            debugger;
          }
          this[`_${propertyName}`] = handler;
          return handler;
        };
        const hookedGetter = function() {
          return this[`_${propertyName}`];
        };
        Object.defineProperty(target, propertyName, {
          get: hookedGetter,
          set: hookedSetter,
          configurable: true,
          enumerable: false
        });
        console.debug(`[${this.name}] Fallback hook created for ${targetType}.${propertyName}`);
      } catch (error) {
        console.error(`[${this.name}] Failed to create fallback for ${targetType}.${propertyName}:`, error);
      }
    }
    /**
     * Finds property descriptor by walking up the prototype chain
     */
    findDescriptorInPrototypeChain(obj, propertyName) {
      let current = obj;
      while (current && current !== Object.prototype) {
        const descriptor = Object.getOwnPropertyDescriptor(current, propertyName);
        if (descriptor) {
          return descriptor;
        }
        current = Object.getPrototypeOf(current);
      }
      return null;
    }
    /**
     * Called when surveillance is detected - script setting event handler property
     */
    monitorEventHandlerAssignment(target, propertyName, handler) {
      try {
        if (typeof handler !== "function") {
          return { shouldProceed: false };
        }
        if (!shouldHookEventHandlerSetter(target, propertyName)) {
          return { shouldProceed: false };
        }
        console.debug(`[${this.name}] Surveillance detected: Event handler assignment ${propertyName} on`, target);
        const eventType = propertyName.substring(2);
        const result = this.evidenceCollector.createAndSendEvidence(
          target,
          eventType,
          "eventHandler"
        );
        return result;
      } catch (error) {
        console.error(`[${this.name}] Error monitoring event handler assignment:`, error);
        return { shouldProceed: false };
      }
    }
  };

  // src/injected/hooks/form-hooks.ts
  var FormHooks = class {
    constructor(evidenceCollector) {
      this.name = "formHooks";
      this.originalDescriptors = [];
      this.originalFunctions = [];
      this.isHookInstalled = false;
      this.documentEventListener = null;
      this.evidenceCollector = evidenceCollector;
    }
    /**
     * Installs all form surveillance detection hooks
     */
    install() {
      if (this.isHookInstalled) {
        console.warn(`[${this.name}] Hook already installed, skipping`);
        return;
      }
      try {
        console.debug(`[${this.name}] Installing form surveillance hooks...`);
        this.installFormDataConstructorHook();
        this.installFormSubmitMethodHook();
        this.installSubmitEventListener();
        this.isHookInstalled = true;
        console.debug(`[${this.name}] Form surveillance hooks installed successfully`);
      } catch (error) {
        console.error(`[${this.name}] Failed to install form hooks:`, error);
        throw error;
      }
    }
    /**
     * Uninstalls all form hooks and restores original behavior
     */
    uninstall() {
      if (!this.isHookInstalled) {
        return;
      }
      try {
        console.debug(`[${this.name}] Uninstalling form surveillance hooks...`);
        this.originalDescriptors.forEach(({ target, propertyName, descriptor }) => {
          try {
            Object.defineProperty(target, propertyName, descriptor);
          } catch (error) {
            console.warn(`[${this.name}] Failed to restore ${propertyName}:`, error);
          }
        });
        this.originalFunctions.forEach(({ target, functionName, originalFunction }) => {
          try {
            target[functionName] = originalFunction;
          } catch (error) {
            console.warn(`[${this.name}] Failed to restore ${functionName}:`, error);
          }
        });
        if (this.documentEventListener) {
          document.removeEventListener("submit", this.documentEventListener, true);
          this.documentEventListener = null;
        }
        this.originalDescriptors = [];
        this.originalFunctions = [];
        this.isHookInstalled = false;
        console.debug(`[${this.name}] Form surveillance hooks uninstalled successfully`);
      } catch (error) {
        console.error(`[${this.name}] Error during hook uninstallation:`, error);
      }
    }
    /**
     * Returns hook installation status
     */
    isInstalled() {
      return this.isHookInstalled;
    }
    /**
     * Install FormData constructor hook - detects form serialization surveillance
     * Based on Explorer's pattern: only report when FormData(formElement) is called
     *
     * Hook mechanism: Replace window.FormData with our version that calls the original
     * Stack trace will show: maliciousScript.js → form-hooks.ts → [native FormData]
     */
    installFormDataConstructorHook() {
      try {
        const originalFormData = window.FormData;
        const self = this;
        this.originalFunctions.push({
          target: window,
          functionName: "FormData",
          originalFunction: originalFormData
        });
        window.FormData = function(form, submitter) {
          const formDataInstance = new originalFormData(form, submitter);
          if (form && form instanceof HTMLFormElement && shouldHookFormDataCreation("FormData")) {
            console.debug(`[${self.name}] FormData constructor called with form:`, form);
            self.monitorFormDataCreation(form, formDataInstance);
          }
          return formDataInstance;
        };
        Object.setPrototypeOf(window.FormData, originalFormData);
        window.FormData.prototype = originalFormData.prototype;
        console.debug(`[${this.name}] FormData constructor hook installed`);
      } catch (error) {
        console.error(`[${this.name}] Failed to install FormData constructor hook:`, error);
        throw error;
      }
    }
    /**
     * Install HTMLFormElement.prototype.submit method hook
     * Hook mechanism: Replace form.submit() method on the prototype
     */
    installFormSubmitMethodHook() {
      try {
        const target = HTMLFormElement.prototype;
        const propertyName = "submit";
        const originalDescriptor = Object.getOwnPropertyDescriptor(target, propertyName);
        if (!originalDescriptor) {
          console.warn(`[${this.name}] No descriptor found for HTMLFormElement.submit`);
          return;
        }
        this.originalDescriptors.push({
          target,
          propertyName,
          descriptor: originalDescriptor
        });
        const self = this;
        const originalSubmit = originalDescriptor.value;
        const hookedSubmit = function() {
          console.debug(`[${self.name}] Form.submit() called on:`, this);
          if (shouldHookFormSubmission(this, "submit")) {
            self.monitorFormSubmission(this, "method");
          }
          return originalSubmit.call(this);
        };
        Object.defineProperty(target, propertyName, {
          value: hookedSubmit,
          writable: originalDescriptor.writable,
          enumerable: originalDescriptor.enumerable,
          configurable: originalDescriptor.configurable
        });
        console.debug(`[${this.name}] HTMLFormElement.submit hook installed`);
      } catch (error) {
        console.error(`[${this.name}] Failed to install form submit method hook:`, error);
        throw error;
      }
    }
    /**
     * Install document-level submit event listener
     * Hook mechanism: Add event listener to document to catch all form submissions
     */
    installSubmitEventListener() {
      try {
        const self = this;
        this.documentEventListener = function(event) {
          if (event.target instanceof HTMLFormElement) {
            console.debug(`[${self.name}] Form submit event detected:`, event.target);
            if (shouldHookFormSubmission(event.target, "submit")) {
              self.monitorFormSubmission(event.target, "event");
            }
          }
        };
        document.addEventListener("submit", this.documentEventListener, true);
        console.debug(`[${this.name}] Submit event listener installed`);
      } catch (error) {
        console.error(`[${this.name}] Failed to install submit event listener:`, error);
        throw error;
      }
    }
    /**
     * Monitor FormData creation - generate evidence for each form field
     * Matches Explorer's pattern of individual evidence per field
     * Uses Explorer's querySelector pattern: form.querySelector(`[name="${key}"]`)
     */
    monitorFormDataCreation(form, formData) {
      try {
        formData.forEach((value, key) => {
          const element = form.querySelector(`[name="${key}"]`);
          if (!element || !isFormElement(element)) {
            return;
          }
          console.debug(`[${this.name}] FormData field detected:`, { key, element });
          const result = this.evidenceCollector.createAndSendEvidence(
            element,
            "FormData",
            "property"
            // Using 'property' as hookType since we're monitoring data access
          );
          if (result.shouldProceed && recordingModeHandler.isCurrentlyRecording() && recordingModeHandler.getMode() === "breakpoint") {
            debugger;
          }
        });
      } catch (error) {
        console.error(`[${this.name}] Error monitoring FormData creation:`, error);
      }
    }
    /**
     * Monitor form submission - generate evidence for each form field
     * Matches Explorer's pattern with form action URL context
     * Uses Explorer's querySelector pattern: form.querySelector(`[name="${key}"]`)
     */
    monitorFormSubmission(form, submissionType) {
      try {
        console.debug(`[${this.name}] Monitoring form submission (${submissionType}):`, form);
        const formData = new FormData(form);
        const formAction = form.action || window.location.href;
        formData.forEach((value, key) => {
          const element = form.querySelector(`[name="${key}"]`);
          if (!element || !isFormElement(element)) {
            return;
          }
          console.debug(`[${this.name}] Form submission field detected:`, { key, element, formAction });
          const action = submissionType === "method" ? "submit" : "addEventListener";
          const hookType = submissionType === "method" ? "property" : "addEventListener";
          const result = this.evidenceCollector.createAndSendEvidence(
            element,
            action,
            hookType
          );
          if (result.shouldProceed && recordingModeHandler.isCurrentlyRecording() && recordingModeHandler.getMode() === "breakpoint") {
            debugger;
          }
        });
      } catch (error) {
        console.error(`[${this.name}] Error monitoring form submission:`, error);
      }
    }
  };

  // src/injected/hook-manager.ts
  var HookManager = class {
    constructor() {
      this.isInitialized = false;
      this.hooksInstalled = false;
      console.debug("[HookManager] Initializing surveillance detection system...");
      try {
        this.elementRegistry = new ElementRegistry();
        this.evidenceCollector = new EvidenceCollector(this.elementRegistry);
        this.addEventListenerHook = new AddEventListenerHook(this.evidenceCollector);
        this.propertyGetterHooks = new PropertyGetterHooks(this.evidenceCollector);
        this.eventHandlerHooks = new EventHandlerHooks(this.evidenceCollector);
        this.formHooks = new FormHooks(this.evidenceCollector);
        this.isInitialized = true;
        console.debug("[HookManager] Core components initialized successfully");
      } catch (error) {
        console.error("[HookManager] Failed to initialize:", error);
        throw error;
      }
    }
    /**
     * Installs all surveillance detection hooks
     */
    installAllHooks() {
      if (!this.isInitialized) {
        throw new Error("Cannot install hooks - initialization failed");
      }
      if (this.hooksInstalled) {
        console.warn("[HookManager] Hooks already installed, skipping");
        return;
      }
      try {
        console.debug("[HookManager] Installing all surveillance detection hooks...");
        this.addEventListenerHook.install();
        this.propertyGetterHooks.install();
        this.eventHandlerHooks.install();
        this.formHooks.install();
        this.hooksInstalled = true;
        console.debug("[HookManager] All surveillance detection hooks installed successfully");
      } catch (error) {
        console.error("[HookManager] Failed to install hooks:", error);
        throw error;
      }
    }
    /**
     * Uninstalls all surveillance detection hooks and cleans up resources
     */
    uninstallAllHooks() {
      if (!this.isInitialized || !this.hooksInstalled) {
        console.debug("[HookManager] No hooks to uninstall");
        return;
      }
      try {
        console.debug("[HookManager] Uninstalling all surveillance detection hooks...");
        this.addEventListenerHook.uninstall();
        this.propertyGetterHooks.uninstall();
        this.eventHandlerHooks.uninstall();
        this.formHooks.uninstall();
        this.hooksInstalled = false;
        console.debug("[HookManager] All surveillance detection hooks uninstalled successfully");
      } catch (error) {
        console.error("[HookManager] Error during hook uninstallation:", error);
        this.hooksInstalled = false;
      }
    }
    /**
     * Signals to content script that hook manager is ready to start evidence collection
     */
    notifyReady() {
      try {
        window.postMessage({
          type: "INJECTED_SCRIPT_READY"
        }, "*");
        console.debug("[HookManager] Sent ready signal to content script");
      } catch (error) {
        console.error("[HookManager] Failed to send ready signal:", error);
      }
    }
    /**
     * Returns comprehensive system statistics for debugging and monitoring
     */
    getStats() {
      if (!this.isInitialized) {
        return null;
      }
      return {
        hookManager: {
          isInitialized: this.isInitialized,
          hooksInstalled: this.hooksInstalled
        },
        elementRegistry: this.elementRegistry.getStats(),
        evidenceCollector: this.evidenceCollector.getStats(),
        filterManager: filterManager.getStats(),
        hooks: {
          addEventListener: this.addEventListenerHook.isInstalled(),
          propertyGetters: this.propertyGetterHooks.isInstalled(),
          eventHandlers: this.eventHandlerHooks.isInstalled(),
          formHooks: this.formHooks.isInstalled()
        }
      };
    }
    /**
     * Returns whether the hook manager is fully initialized and ready
     */
    isReady() {
      return this.isInitialized && this.hooksInstalled;
    }
    /**
     * Returns whether hooks are currently installed
     */
    areHooksInstalled() {
      return this.hooksInstalled;
    }
    /**
     * Returns whether the system is initialized (but hooks may not be installed yet)
     */
    isSystemInitialized() {
      return this.isInitialized;
    }
  };

  // src/injected/main.ts
  if (!window.__REFLECTIZ_INJECTED__) {
    try {
      console.debug("[InjectedScript] Starting Reflectiz surveillance detector...");
      const hookManager = new HookManager();
      window.addEventListener("message", (event) => {
        if (event.source !== window) return;
        if (event.data.type === "SET_RECORDING_MODE") {
          const mode = event.data.recordingMode;
          recordingModeHandler.setMode(mode);
          console.debug(`[InjectedScript] Recording mode set to: ${mode}`);
        } else if (event.data.type === "SET_RECORDING_STATE") {
          const recording = event.data.recording;
          recordingModeHandler.setRecording(recording);
          console.debug(`[InjectedScript] Recording state set to: ${recording}`);
        } else if (event.data.type === "SET_FILTERS") {
          const filters = event.data.filters;
          filterManager.setFilters(filters);
          console.debug(`[InjectedScript] Filters updated:`, filters);
        } else if (event.data.type === "SET_TRACK_EVENTS") {
          const trackEvents = event.data.trackEvents;
          trackEventsManager.setTrackEvents(trackEvents);
          console.debug(`[InjectedScript] Track Events updated:`, trackEvents);
        }
      });
      hookManager.installAllHooks();
      hookManager.notifyReady();
      window.__REFLECTIZ_INJECTED__ = hookManager;
      console.debug("[InjectedScript] Reflectiz surveillance detector running");
    } catch (error) {
      console.error("[InjectedScript] Fatal error during initialization:", error);
    }
  } else {
    console.debug("[InjectedScript] Already initialized, skipping");
  }
})();
