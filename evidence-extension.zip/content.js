"use strict";
(() => {
  // src/content.ts
  var HUD = class {
    constructor() {
      this.state = {
        recording: false,
        eventCount: 0,
        atCap: false,
        recordingMode: "console",
        filters: {
          elementSelector: "",
          attributeFilters: "",
          stackKeywordFilter: ""
        },
        trackEvents: {
          inputValueAccess: true,
          inputEvents: true,
          formSubmit: true,
          formDataCreation: true
        },
        theme: "dark"
      };
      try {
        const savedTheme = localStorage.getItem("hud-theme");
        if (savedTheme === "light" || savedTheme === "dark") {
          this.state.theme = savedTheme;
        }
      } catch (error) {
        console.warn("[HUD] Failed to load theme preference:", error);
      }
      this.hudElement = this.createHUD();
      this.attachHUD();
      this.setupMessageListener();
      this.requestStatus();
    }
    createHUD() {
      const hud = document.createElement("div");
      hud.id = "evidence-hud-overlay";
      hud.innerHTML = `
      <div class="hud-header">
        <h3>Input Monitoring</h3>
        <button class="theme-toggle" title="Toggle light/dark theme">\u{1F319}</button>
      </div>
      <div class="hud-content">
        
        <!-- Status Display -->
        <div class="status-section">
          <div class="recording-status">Not Recording</div>
          <div class="event-count">Events captured: 0</div>
        </div>
        
        <!-- Basic Controls -->
        <div class="controls-section">
          <button class="start-recording">Start Recording</button>
          <button class="stop-recording" disabled>Stop Recording</button>
          <button class="export-data" disabled>Export Data</button>
          <button class="clear-data" disabled>Clear Data</button>
        </div>

        <!-- Message Display -->
        <div class="message-display" style="display: none;"></div>
        
        <!-- Recording Mode Options -->
        <div class="recording-mode-section">
          <h4 class="recording-mode-header">
            <span>Recording Mode</span>
            <button class="recording-mode-toggle" type="button">\u25BC</button>
          </h4>
          <div class="recording-mode-content" style="display: none;">
            <div class="toggle-switch-container">
              <span class="toggle-label left">Console</span>
              <div class="toggle-switch" data-mode="console">
                <div class="toggle-slider"></div>
              </div>
              <span class="toggle-label right">Breakpoint</span>
            </div>
          </div>
        </div>
        
        <!-- Filter Options Section -->
        <div class="filter-section">
          <h4 class="filter-header">
            <span>Filter Options</span>
            <button class="filter-toggle" type="button">\u25BC</button>
          </h4>
          <div class="filter-content" style="display: none;">
            <div class="filter-option">
              <label for="elementSelector">Element Selector (CSS):</label>
              <input type="text" id="elementSelector" class="element-selector" 
                     placeholder="e.g., #myInput, .password, input[name='secret']">
            </div>
            <div class="filter-option">
              <label for="attributeFilters">Attribute Filters:</label>
              <input type="text" id="attributeFilters" class="attribute-filters" 
                     placeholder="e.g., name=password, type=email">
            </div>
            <div class="filter-option">
              <label for="stackKeywordFilter">Stack Keyword Filter:</label>
              <input type="text" id="stackKeywordFilter" class="stack-keyword-filter" 
                     placeholder="e.g., analytics, tracking">
            </div>
          </div>
        </div>

        <!-- Track Events Section -->
        <div class="track-events-section">
          <h4 class="track-events-header">
            <span>Track Events</span>
            <button class="track-events-toggle" type="button">\u25BC</button>
          </h4>
          <div class="track-events-content" style="display: none;">
            <div class="track-events-option">
              <label>
                <input type="checkbox" class="input-value-access" checked>
                <span>Input Value Access</span>
              </label>
              <div class="track-events-description">Monitor property getters (value, nodeValue)</div>
            </div>
            <div class="track-events-option">
              <label>
                <input type="checkbox" class="input-events" checked>
                <span>Input Events</span>
              </label>
              <div class="track-events-description">Monitor addEventListener calls (keydown, input, change)</div>
            </div>
            <div class="track-events-option">
              <label>
                <input type="checkbox" class="form-submit" checked>
                <span>Form Submit</span>
              </label>
              <div class="track-events-description">Monitor form submission events and handlers</div>
            </div>
            <div class="track-events-option">
              <label>
                <input type="checkbox" class="form-data-creation" checked>
                <span>FormData Creation</span>
              </label>
              <div class="track-events-description">Monitor new FormData() constructor calls</div>
            </div>
          </div>
        </div>
             
        <!-- TODO: Advanced Features
             - Real-time event feed/log display
             - Event filtering by domain/source
             - Stack trace highlighting
             - Export format options (JSON, CSV)
             - Session management (save/load configurations) -->
      </div>
    `;
      return hud;
    }
    attachHUD() {
      document.body.appendChild(this.hudElement);
      this.setupEventHandlers();
      this.makeDraggable();
    }
    setupEventHandlers() {
      const startBtn = this.hudElement.querySelector(".start-recording");
      const stopBtn = this.hudElement.querySelector(".stop-recording");
      const exportBtn = this.hudElement.querySelector(".export-data");
      const clearBtn = this.hudElement.querySelector(".clear-data");
      const themeToggle = this.hudElement.querySelector(".theme-toggle");
      const toggleSwitch = this.hudElement.querySelector(".toggle-switch");
      startBtn?.addEventListener("click", () => this.toggleRecording());
      stopBtn?.addEventListener("click", () => this.toggleRecording());
      exportBtn?.addEventListener("click", () => this.exportData());
      clearBtn?.addEventListener("click", () => this.clearData());
      toggleSwitch?.addEventListener("click", () => this.onRecordingModeToggle());
      themeToggle?.addEventListener("click", () => this.onThemeToggle());
      this.setupRecordingModeHandlers();
      this.setupFilterHandlers();
      this.setupTrackEventsHandlers();
    }
    setupFilterHandlers() {
      const filterToggle = this.hudElement.querySelector(".filter-toggle");
      const filterContent = this.hudElement.querySelector(".filter-content");
      const elementSelectorInput = this.hudElement.querySelector(".element-selector");
      const attributeFiltersInput = this.hudElement.querySelector(".attribute-filters");
      const stackKeywordFilterInput = this.hudElement.querySelector(".stack-keyword-filter");
      filterToggle?.addEventListener("click", () => {
        const isVisible = filterContent.style.display !== "none";
        filterContent.style.display = isVisible ? "none" : "block";
        filterToggle.textContent = isVisible ? "\u25BC" : "\u25B2";
      });
      elementSelectorInput?.addEventListener("input", () => this.onFilterChange());
      attributeFiltersInput?.addEventListener("input", () => this.onFilterChange());
      stackKeywordFilterInput?.addEventListener("input", () => this.onFilterChange());
    }
    setupTrackEventsHandlers() {
      const trackEventsToggle = this.hudElement.querySelector(".track-events-toggle");
      const trackEventsContent = this.hudElement.querySelector(".track-events-content");
      const inputValueAccessCheckbox = this.hudElement.querySelector(".input-value-access");
      const inputEventsCheckbox = this.hudElement.querySelector(".input-events");
      const formSubmitCheckbox = this.hudElement.querySelector(".form-submit");
      const formDataCreationCheckbox = this.hudElement.querySelector(".form-data-creation");
      trackEventsToggle?.addEventListener("click", () => {
        const isVisible = trackEventsContent.style.display !== "none";
        trackEventsContent.style.display = isVisible ? "none" : "block";
        trackEventsToggle.textContent = isVisible ? "\u25BC" : "\u25B2";
      });
      inputValueAccessCheckbox?.addEventListener("change", () => this.onTrackEventsChange());
      inputEventsCheckbox?.addEventListener("change", () => this.onTrackEventsChange());
      formSubmitCheckbox?.addEventListener("change", () => this.onTrackEventsChange());
      formDataCreationCheckbox?.addEventListener("change", () => this.onTrackEventsChange());
    }
    setupRecordingModeHandlers() {
      const recordingModeToggle = this.hudElement.querySelector(".recording-mode-toggle");
      const recordingModeContent = this.hudElement.querySelector(".recording-mode-content");
      recordingModeToggle?.addEventListener("click", () => {
        const isVisible = recordingModeContent.style.display !== "none";
        recordingModeContent.style.display = isVisible ? "none" : "block";
        recordingModeToggle.textContent = isVisible ? "\u25BC" : "\u25B2";
      });
    }
    setupMessageListener() {
      chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        switch (message.type) {
          case "HUD_UPDATE":
            this.updateState({
              recording: message.recording ?? this.state.recording,
              eventCount: message.eventCount ?? this.state.eventCount,
              atCap: message.atCap ?? this.state.atCap
            });
            break;
          case "HUD_MESSAGE":
            this.showMessage(message.message, message.level || "info");
            break;
        }
      });
    }
    requestStatus() {
      chrome.runtime.sendMessage({ type: "GET_STATUS" }, (response) => {
        if (response) {
          this.updateState({
            recording: response.recording,
            eventCount: response.eventCount,
            atCap: response.atCap,
            recordingMode: response.recordingMode || "console",
            filters: response.filters || {
              elementSelector: "",
              attributeFilters: "",
              stackKeywordFilter: ""
            },
            trackEvents: response.trackEvents || {
              inputValueAccess: true,
              inputEvents: true,
              formSubmit: true,
              formDataCreation: true
            }
          });
        }
      });
    }
    toggleRecording() {
      chrome.runtime.sendMessage({ type: "TOGGLE_RECORDING" }, (response) => {
        if (response) {
          this.updateState({
            ...this.state,
            recording: response.recording
          });
        }
      });
    }
    exportData() {
      chrome.runtime.sendMessage({ type: "EXPORT_EVENTS" });
    }
    clearData() {
      chrome.runtime.sendMessage({ type: "CLEAR_EVENTS" });
    }
    onThemeToggle() {
      const newTheme = this.state.theme === "dark" ? "light" : "dark";
      this.updateState({ theme: newTheme });
      try {
        localStorage.setItem("hud-theme", newTheme);
      } catch (error) {
        console.warn("[HUD] Failed to save theme preference:", error);
      }
    }
    onRecordingModeToggle() {
      const toggleSwitch = this.hudElement.querySelector(".toggle-switch");
      const currentMode = toggleSwitch.getAttribute("data-mode");
      const newMode = currentMode === "console" ? "breakpoint" : "console";
      this.updateState({ recordingMode: newMode });
      chrome.runtime.sendMessage({
        type: "SET_RECORDING_MODE",
        recordingMode: newMode
      });
    }
    onFilterChange() {
      const elementSelectorInput = this.hudElement.querySelector(".element-selector");
      const attributeFiltersInput = this.hudElement.querySelector(".attribute-filters");
      const stackKeywordFilterInput = this.hudElement.querySelector(".stack-keyword-filter");
      const filters = {
        elementSelector: elementSelectorInput?.value || "",
        attributeFilters: attributeFiltersInput?.value || "",
        stackKeywordFilter: stackKeywordFilterInput?.value || ""
      };
      this.updateState({ filters });
      chrome.runtime.sendMessage({
        type: "SET_FILTERS",
        filters
      });
    }
    onTrackEventsChange() {
      const inputValueAccessCheckbox = this.hudElement.querySelector(".input-value-access");
      const inputEventsCheckbox = this.hudElement.querySelector(".input-events");
      const formSubmitCheckbox = this.hudElement.querySelector(".form-submit");
      const formDataCreationCheckbox = this.hudElement.querySelector(".form-data-creation");
      const trackEvents = {
        inputValueAccess: inputValueAccessCheckbox?.checked || false,
        inputEvents: inputEventsCheckbox?.checked || false,
        formSubmit: formSubmitCheckbox?.checked || false,
        formDataCreation: formDataCreationCheckbox?.checked || false
      };
      this.updateState({ trackEvents });
      chrome.runtime.sendMessage({
        type: "SET_TRACK_EVENTS",
        trackEvents
      });
    }
    updateState(newState) {
      this.state = { ...this.state, ...newState };
      this.updateUI();
    }
    updateUI() {
      const recordingStatus = this.hudElement.querySelector(".recording-status");
      const eventCount = this.hudElement.querySelector(".event-count");
      const startBtn = this.hudElement.querySelector(".start-recording");
      const stopBtn = this.hudElement.querySelector(".stop-recording");
      const exportBtn = this.hudElement.querySelector(".export-data");
      const clearBtn = this.hudElement.querySelector(".clear-data");
      recordingStatus.textContent = this.state.recording ? "Recording..." : "Not Recording";
      recordingStatus.style.color = this.state.recording ? "#4CAF50" : "#666";
      eventCount.textContent = `Events captured: ${this.state.eventCount}`;
      if (this.state.atCap) {
        eventCount.textContent += " (at cap - oldest events dropped)";
        eventCount.style.color = "#FF9800";
      } else {
        eventCount.style.color = "#666";
      }
      startBtn.disabled = this.state.recording;
      stopBtn.disabled = !this.state.recording;
      exportBtn.disabled = this.state.eventCount === 0;
      clearBtn.disabled = this.state.eventCount === 0;
      const toggleSwitch = this.hudElement.querySelector(".toggle-switch");
      const leftLabel = this.hudElement.querySelector(".toggle-label.left");
      const rightLabel = this.hudElement.querySelector(".toggle-label.right");
      if (toggleSwitch && leftLabel && rightLabel) {
        toggleSwitch.setAttribute("data-mode", this.state.recordingMode);
        if (this.state.recordingMode === "console") {
          leftLabel.classList.add("active");
          rightLabel.classList.remove("active");
        } else {
          leftLabel.classList.remove("active");
          rightLabel.classList.add("active");
        }
      }
      const elementSelectorInput = this.hudElement.querySelector(".element-selector");
      const attributeFiltersInput = this.hudElement.querySelector(".attribute-filters");
      const stackKeywordFilterInput = this.hudElement.querySelector(".stack-keyword-filter");
      if (elementSelectorInput) {
        elementSelectorInput.value = this.state.filters.elementSelector;
      }
      if (attributeFiltersInput) {
        attributeFiltersInput.value = this.state.filters.attributeFilters;
      }
      if (stackKeywordFilterInput) {
        stackKeywordFilterInput.value = this.state.filters.stackKeywordFilter;
      }
      const inputValueAccessCheckbox = this.hudElement.querySelector(".input-value-access");
      const inputEventsCheckbox = this.hudElement.querySelector(".input-events");
      const formSubmitCheckbox = this.hudElement.querySelector(".form-submit");
      const formDataCreationCheckbox = this.hudElement.querySelector(".form-data-creation");
      if (inputValueAccessCheckbox) {
        inputValueAccessCheckbox.checked = this.state.trackEvents.inputValueAccess;
      }
      if (inputEventsCheckbox) {
        inputEventsCheckbox.checked = this.state.trackEvents.inputEvents;
      }
      if (formSubmitCheckbox) {
        formSubmitCheckbox.checked = this.state.trackEvents.formSubmit;
      }
      if (formDataCreationCheckbox) {
        formDataCreationCheckbox.checked = this.state.trackEvents.formDataCreation;
      }
      this.hudElement.setAttribute("data-theme", this.state.theme);
      const themeToggle = this.hudElement.querySelector(".theme-toggle");
      if (themeToggle) {
        themeToggle.textContent = this.state.theme === "dark" ? "\u{1F319}" : "\u2600\uFE0F";
        themeToggle.title = this.state.theme === "dark" ? "Switch to light theme" : "Switch to dark theme";
      }
    }
    showMessage(message, level = "info") {
      const messageDiv = this.hudElement.querySelector(".message-display");
      messageDiv.textContent = message;
      messageDiv.style.display = "block";
      messageDiv.className = `message-display message-${level}`;
      setTimeout(() => {
        messageDiv.style.display = "none";
      }, 3e3);
    }
    makeDraggable() {
      const header = this.hudElement.querySelector(".hud-header");
      let isDragging = false;
      let startX = 0;
      let startY = 0;
      let startLeft = 0;
      let startTop = 0;
      header.addEventListener("mousedown", (e) => {
        isDragging = true;
        startX = e.clientX;
        startY = e.clientY;
        const rect = this.hudElement.getBoundingClientRect();
        startLeft = rect.left;
        startTop = rect.top;
        e.preventDefault();
      });
      document.addEventListener("mousemove", (e) => {
        if (!isDragging) return;
        const deltaX = e.clientX - startX;
        const deltaY = e.clientY - startY;
        let newLeft = startLeft + deltaX;
        let newTop = startTop + deltaY;
        const hudRect = this.hudElement.getBoundingClientRect();
        const maxLeft = window.innerWidth - hudRect.width;
        const maxTop = window.innerHeight - hudRect.height;
        newLeft = Math.max(0, Math.min(newLeft, maxLeft));
        newTop = Math.max(0, Math.min(newTop, maxTop));
        this.hudElement.style.left = newLeft + "px";
        this.hudElement.style.top = newTop + "px";
        this.hudElement.style.right = "auto";
      });
      document.addEventListener("mouseup", () => {
        isDragging = false;
      });
    }
  };
  function waitForDomRoot() {
    return new Promise((resolve) => {
      const root = document.head || document.documentElement || document.body;
      if (root) return resolve(root);
      const observer = new MutationObserver(() => {
        const r = document.head || document.documentElement || document.body;
        if (r) {
          observer.disconnect();
          resolve(r);
        }
      });
      observer.observe(document, { childList: true, subtree: true });
    });
  }
  function injectSurveillanceScript() {
    return new Promise(async (resolve, reject) => {
      try {
        const root = await waitForDomRoot();
        const surveillanceScript = document.createElement("script");
        surveillanceScript.src = chrome.runtime.getURL("injected.js");
        surveillanceScript.onload = () => {
          console.debug("[ContentScript] Surveillance script loaded");
          surveillanceScript.remove();
          resolve();
        };
        surveillanceScript.onerror = () => reject(new Error("Failed to load injected surveillance script"));
        root.appendChild(surveillanceScript);
      } catch (e) {
        reject(e);
      }
    });
  }
  function setupInjectedScriptBridge() {
    window.addEventListener("message", (event) => {
      if (event.source !== window) return;
      if (event.data.type === "EVIDENCE_EVENT") {
        if (!chrome.runtime?.id) {
          console.warn("[ContentScript] Extension context invalidated - cannot send evidence");
          return;
        }
        chrome.runtime.sendMessage({
          type: "EVIDENCE_EVENT",
          event: event.data.event
        }).catch((error) => {
          console.error("[ContentScript] Failed to forward evidence to background:", error);
        });
      }
      if (event.data.type === "INJECTED_SCRIPT_READY") {
        console.debug("[ContentScript] Injected script ready, sending handshake");
        window.postMessage({ type: "CONTENT_SCRIPT_READY" }, "*");
        resyncStateFromBackground();
      }
    });
    console.debug("[ContentScript] Injected script bridge set up");
  }
  function resyncStateFromBackground() {
    chrome.runtime.sendMessage({ type: "GET_STATUS" }, (response) => {
      if (!response) return;
      setTimeout(() => {
        window.postMessage({ type: "SET_FILTERS", filters: response.filters || { elementSelector: "", attributeFilters: "", stackKeywordFilter: "" } }, "*");
        window.postMessage({ type: "SET_RECORDING_MODE", recordingMode: response.recordingMode || "console" }, "*");
        window.postMessage({ type: "SET_RECORDING_STATE", recording: !!response.recording }, "*");
        window.postMessage({ type: "SET_TRACK_EVENTS", trackEvents: response.trackEvents || { inputValueAccess: true, inputEvents: true, formSubmit: true, formDataCreation: true } }, "*");
      }, 0);
    });
  }
  function setupControlForwarding() {
    chrome.runtime.onMessage.addListener((message) => {
      switch (message.type) {
        case "SET_RECORDING_MODE":
          window.postMessage({
            type: "SET_RECORDING_MODE",
            recordingMode: message.recordingMode
          }, "*");
          break;
        case "SET_RECORDING_STATE":
          window.postMessage({
            type: "SET_RECORDING_STATE",
            recording: message.recording
          }, "*");
          break;
        case "SET_FILTERS":
          window.postMessage({
            type: "SET_FILTERS",
            filters: message.filters
          }, "*");
          break;
        case "SET_TRACK_EVENTS":
          window.postMessage({
            type: "SET_TRACK_EVENTS",
            trackEvents: message.trackEvents
          }, "*");
          break;
      }
    });
  }
  async function initialize() {
    console.debug("[ContentScript] Initializing Reflectiz content script...");
    try {
      await injectSurveillanceScript();
      setupInjectedScriptBridge();
      setupControlForwarding();
      if (window === window.top) {
        new HUD();
        console.debug("[ContentScript] HUD initialized in main frame");
      } else {
        console.debug("[ContentScript] Skipping HUD in iframe");
      }
      console.debug("[ContentScript] Content script initialization complete");
    } catch (error) {
      console.error("[ContentScript] Failed to initialize:", error);
    }
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initialize);
  } else {
    initialize();
  }
})();
